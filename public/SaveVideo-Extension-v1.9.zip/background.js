/* Save Video — background service worker.
   Jobs:
   (1) Save a media URL the user tapped on, using the browser's own
       download manager (fast path for ordinary public mp4s).
   (2) Inject the content script into tabs that were already open when
       the extension was installed or the browser started (Manifest V3
       content scripts do not auto-inject into already-open tabs, so
       without this the button never appears there until the page is
       reloaded).
   (3) Observe media traffic (webRequest): remember, per tab, the media
       files the page actually fetched, plus any stream manifest
       (.m3u8/.mpd). Players that play through MSE/blob URLs never
       expose a saveable <video> src, and their performance-timeline
       entries are often zero-sized (cross-origin, no Timing-Allow-Origin),
       so the only reliable size signal is the Content-Length the
       network layer saw.
   (4) Save the bytes the content script fetched in the page:
       the page saves them with an anchor click (the only way a
       blob download keeps its real filename — the worker cannot
       create blob URLs, and Chrome drops the filename option for
       blob downloads), while this worker watches the download
       (MT_WATCH) so it can still toast the honest outcome.

   v1.3 — why the save path changed (proven live, 2026-11-21):
   TikTok's video CDN (Akamai) denies its signed video URLs to ANY
   request outside the tiktok.com page context: plain curl 403,
   curl + Referer + Origin + Range 403, extension service-worker
   fetch 403 (511 bytes), while the SAME URL fetched from the page
   context returns 200 with the full 765,371 bytes. The CDN's CORS
   header is `Access-Control-Allow-Origin: https://www.tiktok.com`
   (not *), and the signature is valid ~48h (expire param), so the
   failure is context, not expiry or Referer. Consequence:
   chrome.downloads.download on the observed URL fails with
   "File wasn't available on site", and an MV3 offscreen document
   (extension origin) would fail exactly the same way — so v1.3 does
   NOT use offscreen fetching. Instead the content script fetches the
   bytes in the page (page origin + cookies — the only context the
   CDN accepts) and streams them here in 4 MB chunks; this worker
   reassembles them into a Blob and saves that. Direct download stays
   the fast path for ordinary (unsigned, public) mp4s, and a failed
   direct download automatically retries through the page fetch.
   (5) Honest status: the worker watches downloads.onChanged and
   tells the page's toast the truth — "Saved." only when the
   download actually completes, the real reason when it fails.
   (6) v1.4 — instant start (2026-11-21): the fetch-then-blob path
   made every save start seconds late with no feedback. The primary
   path is now an anchor click on the observed URL: the extension's
   declarativeNetRequest rules (rules.json) add
   `Content-Disposition: attachment` to main-frame navigations to
   the video CDNs, so the click starts a real download immediately
   (proven live: file in Downloads ~1 s after the click). This
   worker registers the filename (for onDeterminingFilename) and
   watches for the download; if none appears within 4 s it closes
   any stray tab and asks the page to fall back to the fetch path.
   A plain anchor click does NOT work on its own — Chrome ignores
   the download attribute for cross-origin URLs (proven: _blank
   does nothing, no-target navigates the tab away) — the DNR rule
   is what makes it a download.
   (7) v1.5 — duplicate guard (2026-11-22): one video = one save.
   The key is the media URL without its query string; the worker
   records 'downloading' when a save is accepted and 'saved' when it
   completes, persisted in chrome.storage.local so it survives a
   worker restart. A repeat click on an already-saved video asks
   first, in the page toast — "This file is already downloaded.
   Download again?" with [Download again] / [Cancel]; "Download
   again" bypasses the guard for that one click (force), Cancel —
   or ignoring the prompt — downloads nothing. A repeat click on a
   video that is still downloading toasts "Already downloading."
   and starts nothing. A failed attempt releases the record so a
   retry works.
   (8) v1.6 — all platforms (2026-11-23): the observer and the save
   paths are site-agnostic (any progressive mp4 the page fetches),
   with per-platform handling where the delivery differs. YouTube
   serves SABR/UMP streams only (no progressive mp4 in the player
   response, adaptive formats carry no direct URL, and a plain GET
   of the observed videoplayback URL answers "sabr.malformed_
   config") — so googlevideo videoplayback URLs are never recorded
   as saveable, and YouTube saves only when the page's own player
   response lists a progressive mp4 (MT_YT_FORMATS, read in the
   page's MAIN world); otherwise the honest stream toast is shown.
   Facebook/Instagram serve progressive mp4 (fbcdn/cdninstagram)
   and are saved by the same anchor/fetch paths as TikTok. X,
   Reddit and Dailymotion are HLS/DASH-only (no single mp4 file
   exists to save) — the extension reports that honestly instead
   of saving a broken file. Instagram serves DASH byte-ranges: the
   range params are stripped, because the bare URL serves the whole
   file while a single range is an unplayable fragment. Vimeo lists
   progressive mp4s in its player config (MT_FETCH_TEXT, read in
   the page context).
   (9) v1.6 — download folder + ask-each-time (2026-11-23): the
   popup offers a "Download folder" (a subfolder inside Downloads,
   e.g. "Save Video"; empty = Auto, files go straight to Downloads) and an
   "Ask where to save each time" toggle (default off). Both are
   persisted in chrome.storage.local (mt_folder, mt_ask) and cached
   in the worker (storage.onChanged keeps the cache fresh), so the
   click-to-save path costs nothing extra. The folder is prepended
   to the filename on EVERY save path (anchor rule, direct download,
   blob/MAIN-world download, fetch-blob anchor in the page); the
   guard key stays the media URL, and the stored record keeps the
   prefixed filename so the already-saved check still matches.
   The folder input is sanitized (no absolute paths, no "..", no
   illegal characters); an invalid value is ignored (Auto).
   "Ask where to save" opens Chrome's Save dialog for downloads
   started through the download manager; the instant anchor path
   (signed video URLs) is a navigation and cannot show a dialog,
   so those files still save automatically. Cancelling a download
   (including dismissing the Save dialog) never retries — nothing
   downloads after a cancel.
   No data is collected, uploaded or sent anywhere. The observer only
   keeps URLs + sizes in memory, per tab, and forgets them when the
   tab closes. No remote code, no analytics, no external requests.

   (10) v1.7 — per-video resolution + no stored data + merge (2026-11-23):
   The tab-global "largest mp4 wins" resolution downloaded the WRONG
   video on feed pages (several videos preload at once), so a button
   now resolves the URL for ITS video only: the element's own
   currentSrc, else the mp4 first observed while THAT video is playing
   (MT_BEST_FOR_VIDEO — timed to the element's play start), else the
   platform resolver for that video (Facebook reel id, YouTube player
   response). If no URL can be tied to the playing video with
   confidence, the honest "couldn't find" toast is shown — a wrong
   file is worse than no file. The duplicate guard keeps NO persisted
   video data: no persisted download record, no filename matching, no session
   storage — the in-progress/saved record lives only in this worker's
   memory, and "already downloaded" across restarts is detected from
   the browser's own download history (chrome.downloads.search),
   matched on the download's URL only, never the title/filename.
   YouTube and other HLS/DASH-only platforms merge separate streams
   in an offscreen document with bundled ffmpeg.wasm 0.12
   (single-threaded; the 0.11 core needed SharedArrayBuffer and
   crashed) — video-only mp4 + audio m4a, -c copy, no re-encode. */

// Skip branding / splash / loading clips — those are never the video
// the user is watching, however large they happen to be.
const SKIP_NAME_RE = /logo|splash|loading|brand|intro|watermark/i;
// Minimum size for a webRequest candidate to count as "the video".
// Anything smaller is a sticker, emoji, preview or logo clip.
// 500 KB (not 1 MB): a 576p TikTok episode is only ~765 KB, while
// the TikTok logo clip is ~199 KB — 500 KB keeps the logo out and
// still catches short videos on their first fetch.
const MIN_MEDIA_BYTES = 500_000;
// A recorded URL counts as fresh for this long. Signed video URLs go
// stale fast once the player stops fetching (the player re-fetches
// while the video plays, so a playing video's URL stays fresh).
const FRESH_MS = 120_000;
// Chunk size for the content-script -> worker byte transfer.
const BLOB_CHUNK = 4 * 1024 * 1024;
// Drop an unfinished byte transfer after this long.

function isMediaRequest(url, contentType) {
  if (typeof url !== 'string') return false;
  const path = url.split('?')[0].toLowerCase();
  if (path.endsWith('.mp4') || path.endsWith('.flv') || path.endsWith('.webm') ||
      path.endsWith('.mov') || path.endsWith('.mkv')) return true;
  if (url.indexOf('mime_type=video_mp4') !== -1) return true;
  if (typeof contentType === 'string' && contentType.toLowerCase().indexOf('video/') === 0) return true;
  return false;
}

function isStreamManifest(url) {
  if (typeof url !== 'string') return false;
  const path = url.split('?')[0].toLowerCase();
  return path.endsWith('.m3u8') || path.endsWith('.mpd');
}

// DASH byte-range params (see recordMedia): strip bytestart/byteend
// so a ranged fragment URL becomes the whole-file URL.
function stripByteRange(u) {
  if (typeof u !== 'string') return u;
  if (u.indexOf('bytestart=') === -1 && u.indexOf('byteend=') === -1) return u;
  const q = u.indexOf('?');
  if (q === -1) return u;
  const kept = u.slice(q + 1).split('&').filter((p) => p.indexOf('bytestart=') !== 0 && p.indexOf('byteend=') !== 0);
  return kept.length ? u.slice(0, q + 1) + kept.join('&') : u.slice(0, q);
}

/* ---------- download folder + ask-each-time settings ---------- */

// Popup settings (chrome.storage.local): mt_folder = a subfolder
// inside Downloads ('' = Auto, files go straight to Downloads);
// mt_ask = open Chrome's Save dialog for every download. Cached
// here so the click-to-save path costs no storage round trip;
// storage.onChanged keeps the cache fresh when the popup changes
// a value between saves.
let folderCache = '';
let askCache = false;

function sanitizeFolder(raw) {
  if (typeof raw !== 'string') return '';
  const t = raw.trim();
  if (!t) return '';
  if (t.length > 100) return '';
  if (t.startsWith('/') || t.startsWith('\\') || t.includes(':') || t.includes('\\')) return '';
  const parts = t.split('/');
  if (parts.length > 5) return '';
  for (const p of parts) {
    const s = p.trim();
    if (!s || s === '.' || s === '..') return '';
    if (/[<>:"|?*\x00-\x1F]/.test(s)) return '';
    if (s.endsWith('.') || s.endsWith(' ')) return '';
  }
  return parts.map((p) => p.trim()).join('/');
}

function loadSettings() {
  try {
    chrome.storage.local.get({ mt_folder: '', mt_ask: false }, (r) => {
      folderCache = sanitizeFolder(r && r.mt_folder);
      askCache = !!(r && r.mt_ask);
    });
  } catch (e) { /* defaults stand */ }
}
loadSettings();
if (chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.mt_folder) folderCache = sanitizeFolder(changes.mt_folder.newValue);
    if (changes.mt_ask) askCache = !!changes.mt_ask.newValue;
  });
}

// Prepend the download folder to a filename ("Save Video/video.mp4").
// Idempotent: a filename that already starts with the folder is
// returned unchanged (the page and the worker both apply it).
function applyFolder(filename) {
  const name = String(filename || 'video.mp4');
  if (!folderCache) return name;
  const prefix = folderCache + '/';
  if (name.startsWith(prefix)) return name;
  return prefix + name;
}

function headerValue(headers, name) {
  if (!headers) return null;
  const lower = name.toLowerCase();
  for (const h of headers) {
    if (h && typeof h.name === 'string' && h.name.toLowerCase() === lower) return h.value;
  }
  return null;
}

// tabId -> { byUrl: Map(url -> {total, lastSeen}), bestMp4: {url, size} | null,
//              stream: {url} | null, seenAt }
const mediaByTab = new Map();
const MAX_TABS = 50;

// Tabs opened for a visitor who pasted a YouTube link on the Save
// Video website (MT_SITE_YT_SAVE): the video page must stay open
// while the merge runs (MT_REFRESH_URL needs the tab's MAIN world),
// then the tab is closed so the visitor never sees it.
const siteYtTabs = new Map();
function closeSiteYtTab(tabId) {
  if (!siteYtTabs.has(tabId)) { diagLog('closeSiteYtTab SKIP tab=' + tabId + ' (not a site tab)'); return; }
  siteYtTabs.delete(tabId);
  try {
    chrome.tabs.remove(tabId, function () {
      if (chrome.runtime.lastError) diagLog('closeSiteYtTab tab=' + tabId + ' FAILED: ' + chrome.runtime.lastError.message);
      else diagLog('closeSiteYtTab tab=' + tabId + ' closed');
    });
  } catch (e) { diagLog('closeSiteYtTab tab=' + tabId + ' threw: ' + String((e && e.message) || e)); }
}

function recordMedia(tabId, url, size, mime) {
  if (typeof tabId !== 'number' || tabId < 0) return;
  // DASH byte-range URLs (Instagram serves video as bytestart/byteend
  // ranges of one file): the bare URL serves the WHOLE file
  // (ftyp+moov+all fragments — proven live, 2026-11-23), while any
  // single range is an unplayable fragment (moof without moov).
  // Strip the range params so all ranges of one file accumulate
  // under one key and the saved URL is the whole file.
  url = stripByteRange(url);
  if (SKIP_NAME_RE.test(url)) return; // never a logo/splash clip
  let rec = mediaByTab.get(tabId);
  if (!rec) {
    rec = { byUrl: new Map(), bestMp4: null, stream: null, seenAt: Date.now() };
    if (mediaByTab.size >= MAX_TABS) {
      // Evict the oldest tab entry.
      let oldestId = null;
      let oldestAt = Infinity;
      mediaByTab.forEach((r, id) => { if (r.seenAt < oldestAt) { oldestAt = r.seenAt; oldestId = id; } });
      if (oldestId !== null) mediaByTab.delete(oldestId);
    }
    mediaByTab.set(tabId, rec);
  }
  const now = Date.now();
  rec.seenAt = now;
  // Players fetch video in range chunks: accumulate bytes per URL, so a
  // multi-MB video fetched in pieces still beats a single small clip.
  const prev = rec.byUrl.get(url) || { total: 0, lastSeen: 0, firstSeen: now, mime: '' };
  const total = prev.total + size;
  rec.byUrl.set(url, { total, lastSeen: now, firstSeen: prev.firstSeen || now, mime: mime || prev.mime || '' });
  // Keep the largest file: biggest = best quality.
  if (!rec.bestMp4 || total > rec.bestMp4.size) {
    rec.bestMp4 = { url, size: total };
  }
}

function recordStream(tabId, url) {
  if (typeof tabId !== 'number' || tabId < 0) return;
  let rec = mediaByTab.get(tabId);
  if (!rec) {
    rec = { byUrl: new Map(), bestMp4: null, stream: null, seenAt: Date.now() };
    mediaByTab.set(tabId, rec);
  }
  rec.seenAt = Date.now();
  rec.stream = { url };
}

// Best media for ONE video (v1.7): the mp4 fetched for THIS video.
// `sinceMs` is the epoch ms when the video element started playing
// (the content script reports it). A feed page preloads several
// videos at once, so the tab-global "largest mp4 wins" (v1.6)
// regularly picked a DIFFERENT video — an ad or the next reel. Here
// a URL only counts if its fetch OVERLAPPED the window around this
// video's play start (3 s grace either side): the fetch must have
// started by then and still been active then, or started around
// then. This is the correct shape for both patterns — a blob/MSE
// player fetches first and plays when the fetch ends (fetch start
// can be seconds before play on a slow network, but its lastSeen is
// at play time), and a streaming player fetches continuously while
// playing. A video played minutes ago has firstSeen AND lastSeen
// long before the window, so it is excluded even if its accumulated
// total is the largest (that is the v1.6 wrong-video bug: the old
// firstSeen-only check plus a since=0 anchor picked the earlier
// video's double-counted total).
//
// Fallback (v1.7 fix, 2026-11-23 — TikTok "link not found"): the
// strict window misses real videos in two common cases — (a) the
// player preloads the video and its fetch FINISHES before the play
// event fires (lastSeen < since - 3000), and (b) a long watch means
// the fetch ended more than FRESH_MS (2 min) before the click. The
// user reported many TikTok videos failing with "link not found"
// while v1.4/v1.6 saved them, so a strict null here is worse than a
// careful fallback. Tier 2: the most recently active fetch that
// STARTED at or before this video's play start (+3 s grace) — a
// preload that started AFTER this video began playing belongs to the
// NEXT video, so it is excluded. Tier 3: the freshest observed mp4
// in the tab, any age (the record only lives while the tab is open).
// Never return null while a usable mp4 was observed in this tab.
function bestMediaForVideo(tabId, sinceMs) {
  const rec = mediaByTab.get(tabId);
  if (!rec) return null;
  const now = Date.now();
  const since = (typeof sinceMs === 'number' && sinceMs > 0) ? sinceMs : 0;
  const toResult = (best) => ({
    bestMp4: best.url,
    bestSize: best.size,
    stream: rec.stream ? rec.stream.url : null,
    fresh: true,
    seenAt: best.lastSeen,
    mime: best.mime
  });
  let best = null;
  rec.byUrl.forEach((v, url) => {
    if (now - v.lastSeen > FRESH_MS) return; // stale
    if (since > 0) {
      const first = v.firstSeen || 0, last = v.lastSeen || 0;
      if (first > since + 3000 || last < since - 3000) return; // fetch did not overlap this video's play window
    }
    if (!best || v.total > best.size) {
      best = { url, size: v.total, firstSeen: v.firstSeen || 0, lastSeen: v.lastSeen, mime: v.mime || '' };
    }
  });
  if (best) return toResult(best);
  // Tier 2: most recently active fetch that started at/before this
  // video's play start (+3 s grace). No freshness filter: a long
  // watch must not make the video unfindable.
  let fb = null;
  rec.byUrl.forEach((v, url) => {
    const first = v.firstSeen || 0;
    if (since > 0 && first > since + 3000) return; // started after this video began playing — the next video's preload
    if (!fb || (v.lastSeen || 0) > fb.lastSeen) {
      fb = { url, size: v.total, firstSeen: first, lastSeen: v.lastSeen, mime: v.mime || '' };
    }
  });
  if (fb) return toResult(fb);
  // Tier 3: freshest observed mp4 in the tab, any age.
  let fb3 = null;
  rec.byUrl.forEach((v, url) => {
    if (!fb3 || (v.lastSeen || 0) > fb3.lastSeen) {
      fb3 = { url, size: v.total, firstSeen: v.firstSeen || 0, lastSeen: v.lastSeen, mime: v.mime || '' };
    }
  });
  if (!fb3) return null;
  return toResult(fb3);
}

if (typeof chrome !== 'undefined' && chrome.webRequest && chrome.webRequest.onHeadersReceived) {
  chrome.webRequest.onHeadersReceived.addListener(
    (details) => {
      const url = details.url || '';
      // YouTube's SABR/UMP session URLs are not downloadable files:
      // a plain GET answers "sabr.malformed_config" (proven live,
      // 2026-11-23). Never record them as the video, whatever their
      // content-type claims.
      if (/googlevideo\.com\/videoplayback/i.test(url)) return;
      // The extension's own download re-fetching this URL: not the
      // player's fetch, so it must not extend the observation window
      // (see markOwnDownload — it would make a just-downloaded video
      // win the next video's resolution).
      if (isOwnDownload(url)) return;
      if (isStreamManifest(url)) {
        recordStream(details.tabId, url);
        return;
      }
      const contentType = headerValue(details.responseHeaders, 'content-type');
      if (!isMediaRequest(url, contentType)) return;
      const len = parseInt(headerValue(details.responseHeaders, 'content-length') || '', 10);
      const size = isNaN(len) ? 0 : len;
      // Only count files big enough to be a real video; a small
      // media file is a sticker/preview, not the video.
      if (size > 0 && size < MIN_MEDIA_BYTES) return;
      recordMedia(details.tabId, url, size, contentType || '');
    },
    { urls: ['http://*/*', 'https://*/*'], types: ['xmlhttprequest', 'media', 'other'] },
    ['responseHeaders']
  );
}

chrome.tabs.onRemoved.addListener((tabId) => {
  mediaByTab.delete(tabId);
  // Drop pending downloads/transfers for the closed tab.
  pendingDownloads.forEach((p, id) => { if (p.tabId === tabId) pendingDownloads.delete(id); });
});

// The filename passed to chrome.downloads.download() is only a
// suggestion: current Chromium can drop it (service-worker eviction,
// headless quirks), and the file then lands under the URL's basename
// — for TikTok URLs that is a hash with no .mp4 extension at all.
// The reliable path is downloads.onDeterminingFilename: suggest the
// intended name there. The pending name is kept in memory ONLY
// (v1.7 — no video data is persisted anywhere). If the worker
// restarts mid-download the name is lost and the file lands under
// the URL's basename; that is the price of keeping no records.
// It is keyed by URL as well as by download id: rememberName(id)
// runs in the downloads.download callback, which fires AFTER
// onDeterminingFilename — too late when the filename option was
// dropped (blob URLs land as a UUID without this).
const pendingNames = new Map();
const pendingNamesByUrl = new Map();
const MAX_PENDING = 50;

function rememberNameForUrl(url, filename) {
  if (!url || !filename) return;
  pendingNamesByUrl.set(url, filename);
  if (pendingNamesByUrl.size > MAX_PENDING) {
    const first = pendingNamesByUrl.keys().next().value;
    pendingNamesByUrl.delete(first);
  }
}

function rememberName(downloadId, filename) {
  if (typeof downloadId !== 'number' || !filename) return;
  pendingNames.set(downloadId, filename);
  if (pendingNames.size > MAX_PENDING) {
    const first = pendingNames.keys().next().value;
    pendingNames.delete(first);
  }
}

// Small diagnostic log, in memory only (v1.7 — the old log lived in
// chrome.storage.local and its entries contained video URLs, which is
// persisted video data). Readable from the service-worker console via
// globalThis.__mtDiag.
const diagMem = [];
function diagLog(line) {
  try {
    const entry = new Date().toISOString().slice(11, 19) + ' ' + line;
    diagMem.push(entry);
    if (diagMem.length > 60) diagMem.shift();
    console.log('[MT] ' + entry);
  } catch (e) { /* logging must never break the save */ }
}
globalThis.__mtDiag = diagMem;

// Most recent anchor download's intended filename. The anchor
// navigation can redirect (the CDN answers from another host), so
// the download's final URL may not match the registered one —
// onDeterminingFilename then falls back to this recency match
// (an anchor download is the only download the extension starts,
// and the name is only trusted for ~20 s).
let lastAnchorName = null; // {filename, at}

/* ---------- duplicate-download guard (v1.7 — no stored data) ---------- */

// One video = one save. The key is the media URL without its query
// string (a signed URL's signature rotates, but the path is the
// video), so the same video re-observed with a fresh signature is
// still the same video. The guard is keyed ONLY on that video
// identity — never on the title/filename: two different videos that
// happen to share a title are NOT duplicates and both must download
// (Chrome names the second "title (1).mp4"); the same video must
// never download twice.
// NO video data is persisted anywhere in the extension (v1.7):
// - the in-progress/saved record lives ONLY in this worker's memory
//   and is forgotten when the worker closes;
// - "already downloaded" across restarts is detected from the
//   BROWSER's own download history (chrome.downloads.search),
//   matched on the download's URL (finalUrl/url) — never on the
//   filename/title alone.
// The user's own SETTINGS (folder, ask toggle, enable toggle) still
// live in chrome.storage.local — those are his settings, not video
// data. Blob URLs are revoked after use; no bytes are cached.
const DUP_DOWNLOADING_TTL_MS = 30 * 60 * 1000;
const MAX_SAVED = 200;

const savedMap = new Map(); // key -> {state, filename, downloadId, url, at} — memory only

function keyForUrl(url) {
  if (typeof url !== 'string') return '';
  return url.split('?')[0];
}

// URLs the extension itself is downloading (anchor navigation,
// chrome.downloads, offscreen merge fetches), keyed by URL without
// query string. The webRequest observer must IGNORE these: the
// download re-fetches the same URL the player already fetched, and
// recording it would extend that URL's lastSeen and inflate its
// total — so a video downloaded moments ago stays a candidate for
// the NEXT video's play window and, being larger, wins over the
// video actually playing (proven 2026-11-23: f.mp4's download
// re-fetch at ...951128 fell inside vidB's play window and its
// doubled total 8,695,996 beat g.mp4's 6,180,966). Marks expire
// after 10 min as a backstop and are cleared when the download
// finishes (forgetDownload).
const ownDownloadUrls = new Map(); // urlKey -> expiryMs
function markOwnDownload(url) {
  const k = keyForUrl(url);
  if (k) ownDownloadUrls.set(k, Date.now() + 600000);
}
function unmarkOwnDownload(url) {
  ownDownloadUrls.delete(keyForUrl(url));
}
function isOwnDownload(url) {
  const k = keyForUrl(url);
  if (!k) return false;
  const exp = ownDownloadUrls.get(k);
  if (!exp) return false;
  if (exp < Date.now()) { ownDownloadUrls.delete(k); return false; }
  return true;
}

function regexEscape(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function pruneSaved() {
  if (savedMap.size <= MAX_SAVED) return;
  const entries = [...savedMap.entries()].sort((a, b) => a[1].at - b[1].at);
  for (const [k] of entries) {
    if (savedMap.size <= MAX_SAVED) break;
    savedMap.delete(k);
  }
}

function reserveSave(key, info) {
  if (!key) return;
  savedMap.set(key, { state: 'downloading', filename: info.filename || '', downloadId: null, url: info.url || '', at: Date.now() });
  pruneSaved();
}

function markSaved(key, downloadId) {
  if (!key) return;
  const rec = savedMap.get(key);
  if (rec) {
    rec.state = 'saved';
    if (typeof downloadId === 'number') rec.downloadId = downloadId;
    rec.at = Date.now();
  } else {
    savedMap.set(key, { state: 'saved', filename: '', downloadId: (typeof downloadId === 'number') ? downloadId : null, url: '', at: Date.now() });
  }
  pruneSaved();
}

function releaseSave(key) {
  if (!key) return;
  savedMap.delete(key);
}

// Check whether this video is already downloading or saved.
// Returns {dup:false} or {dup:true, state:'downloading'|'saved'}.
// The match is by VIDEO identity (media URL without query string)
// only: (1) this session's in-memory record, (2) the browser's own
// download history, matched on the download's URL/finalUrl — never
// on the filename/title. Fail-open: any error in the check itself
// allows the save — the guard must never block a first download.
async function checkDuplicate(key, url) {
  try {
    const now = Date.now();
    const rec = savedMap.get(key);
    if (rec) {
      if (rec.state === 'downloading') {
        if (now - rec.at > DUP_DOWNLOADING_TTL_MS) {
          releaseSave(key);
        } else {
          return { dup: true, state: 'downloading' };
        }
      } else if (rec.state === 'saved') {
        // Verify the file is really still there: if the user deleted
        // it (or cleared download history), allow a fresh save.
        if (typeof rec.downloadId === 'number') {
          const items = await chrome.downloads.search({ id: rec.downloadId });
          const item = items && items[0];
          if (!item || item.exists === false) {
            releaseSave(key);
          } else {
            return { dup: true, state: 'saved' };
          }
        } else {
          return { dup: true, state: 'saved' };
        }
      }
    }
    // Cross-restart backstop: the browser's own download history.
    // Match on the download's URL for THIS video's media path — a
    // different video with the same title has a different URL and
    // must NOT match. The urlRegex pre-filters on the download URL;
    // the JS check also accepts a finalUrl match (CDN redirect).
    // `url` is the real media URL; the guard key may be synthetic
    // (YouTube merges use 'yt:<videoId>'), so the regex is built
    // from the URL, never from the key.
    if (url) {
      const ukey = keyForUrl(url);
      const items = await chrome.downloads.search({
        urlRegex: '^' + regexEscape(ukey) + '(\\?.*)?$',
        state: 'complete',
        limit: 20
      });
      for (const item of (items || [])) {
        if (item.exists === false) continue;
        if (keyForUrl(item.url || '') === ukey || keyForUrl(item.finalUrl || '') === ukey) {
          return { dup: true, state: 'saved' };
        }
      }
    }
    return { dup: false };
  } catch (e) {
    return { dup: false };
  }
}

/* ---------- dynamic filename rule (instant anchor path) ---------- */

// onDeterminingFilename does NOT fire for navigation-initiated
// downloads (proven live: zero ODF lines across anchor downloads),
// so the filename cannot be fixed there. Instead, just before the
// anchor click, a dynamic net-request rule is installed that sets
// `Content-Disposition: attachment; filename="<title>.mp4"` on the
// response for that exact URL — Chrome then saves the file under
// the right name directly. The static rules in rules.json stay as
// the backstop (attachment without a name) in case this fails.
// The rule is removed as soon as the download is claimed (or the
// anchor watchdog fires), so it never lingers.
const DNR_DYNAMIC_RULE_ID = 1001;

async function setAnchorFilenameRule(url, filename) {
  try {
    if (!chrome.declarativeNetRequest || !chrome.declarativeNetRequest.updateDynamicRules) return false;
    const escaped = url.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const safeName = String(filename || 'video.mp4').replace(/["\r\n]/g, '').replace(/[^\x20-\x7E]/g, '');
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [DNR_DYNAMIC_RULE_ID],
      addRules: [{
        id: DNR_DYNAMIC_RULE_ID,
        priority: 10,
        action: {
          type: 'modifyHeaders',
          responseHeaders: [{ header: 'content-disposition', operation: 'set', value: 'attachment; filename="' + safeName + '"' }]
        },
        condition: { regexFilter: '^' + escaped + '$', resourceTypes: ['main_frame'] }
      }]
    });
    return true;
  } catch (e) { return false; }
}

async function clearAnchorFilenameRule() {
  try {
    if (chrome.declarativeNetRequest && chrome.declarativeNetRequest.updateDynamicRules) {
      await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [DNR_DYNAMIC_RULE_ID] });
    }
  } catch (e) { /* cleanup must never break the save */ }
}

if (typeof chrome !== 'undefined' && chrome.downloads && chrome.downloads.onDeterminingFilename) {
  chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
    diagLog('ODF url=' + String(item.url).slice(0, 70) + ' id=' + item.id + ' itemFile=' + item.filename);
    // First: the name stored by URL before the download was started.
    const byUrl = pendingNamesByUrl.get(item.url);
    if (byUrl) {
      diagLog('ODF byUrl HIT -> ' + byUrl);
      pendingNamesByUrl.delete(item.url);
      suggest({ filename: byUrl, conflictAction: 'uniquify' });
      return;
    }
    const name = pendingNames.get(item.id);
    if (name) {
      pendingNames.delete(item.id);
      suggest({ filename: name, conflictAction: 'uniquify' });
      return;
    }
    // Recency fallback: the anchor navigation may have redirected,
    // so the download's final URL no longer matches the registered
    // one. An anchor download is the only download this extension
    // starts, so a very recent anchor name is a safe match.
    if (lastAnchorName && Date.now() - lastAnchorName.at < 20000) {
      diagLog('ODF recency HIT -> ' + lastAnchorName.filename);
      suggest({ filename: lastAnchorName.filename, conflictAction: 'uniquify' });
      return;
    }
    // No in-memory name (worker may have restarted): there is no
    // persisted name to fall back on (v1.7 keeps no video records),
    // so echo the tentative name back (a no-op) — the download is
    // never left waiting on us.
    diagLog('ODF MISS, echo ' + item.filename);
    suggest({ filename: (item.filename || 'video.mp4').split('/').pop(), conflictAction: 'uniquify' });
  });
}

/* ---------- honest download status + retry ---------- */

// blob: URL -> {filename, tabId, frameId, timer}: downloads the page
// starts itself with an anchor click (the only way a blob download
// keeps its real filename). The background watches for them so it
// can still toast "Saved." only when they really complete.
const watchByUrl = new Map();

function watchDownload(url, filename, tabId, frameId, key) {
  if (!url || !filename) return;
  const old = watchByUrl.get(url);
  if (old && old.timer) clearTimeout(old.timer);
  const timer = setTimeout(() => watchByUrl.delete(url), 60000);
  watchByUrl.set(url, { filename, tabId, frameId, timer, key: key || '' });
}

/* ---------- instant anchor path: watchdog + fallback ---------- */

// url -> {tabId, frameId, filename, url, at, timer, blankTabId,
// fallbackSent}: an anchor click the page is about to make (or just
// made). The net-request rules turn the navigation into a download;
// if no download appears within ANCHOR_WATCH_MS, the rule missed —
// close any stray tab and fall back to the fetch path.
const pendingAnchors = new Map();
const ANCHOR_WATCH_MS = 4000;

function triggerAnchorFallback(url) {
  const p = pendingAnchors.get(url);
  if (!p || p.fallbackSent) return;
  p.fallbackSent = true;
  if (p.timer) clearTimeout(p.timer);
  pendingAnchors.delete(url);
  lastAnchorName = null;
  clearAnchorFilenameRule();
  sendToast(p.tabId, p.frameId, 'Retrying…');
  try {
    const opts = (typeof p.frameId === 'number' && p.frameId >= 0) ? { frameId: p.frameId } : undefined;
    const pr = opts
      ? chrome.tabs.sendMessage(p.tabId, { type: 'MT_FETCH_TRANSFER', url: p.url, filename: p.filename }, opts)
      : chrome.tabs.sendMessage(p.tabId, { type: 'MT_FETCH_TRANSFER', url: p.url, filename: p.filename });
    if (pr && pr.then) {
      pr.then((res) => {
        if (!res || !res.ok) {
          // The fallback fetch failed too — release the duplicate
          // guard so the user can retry this video.
          releaseSave(p.key);
          sendToast(p.tabId, p.frameId, 'Save failed — please try again.');
        }
      }).catch(() => {
        releaseSave(p.key);
        sendToast(p.tabId, p.frameId, 'Save failed — please try again.');
      });
    }
  } catch (e) {
    releaseSave(p.key);
    sendToast(p.tabId, p.frameId, 'Save failed — please try again.');
  }
}

if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.onCreated) {
  chrome.tabs.onCreated.addListener((tab) => {
    // The anchor opens target=_blank: a tab whose opener is the tab
    // that clicked is the anchor's blank tab. As a backstop, any
    // about:blank tab created while an anchor is pending is recorded
    // as a candidate — it is only ever closed if it is STILL
    // about:blank after the download starts (see below).
    pendingAnchors.forEach((p) => {
      if (tab.openerTabId === p.tabId && !p.blankTabId) {
        p.blankTabId = tab.id;
        diagLog('ANCHOR blank tab (opener) id=' + tab.id);
      } else if (!p.blankTabId && (!tab.url || tab.url === 'about:blank')) {
        p.blankTabId = tab.id;
        p.blankTabCandidate = true;
        diagLog('ANCHOR blank tab (candidate) id=' + tab.id);
      }
    });
  });
}

if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.onUpdated) {
  chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (!changeInfo.url) return;
    pendingAnchors.forEach((p, url) => {
      // A tab navigated to the video itself: the rule missed.
      // Close it and fall back to the fetch path.
      if (changeInfo.url === url && tabId !== p.tabId) {
        try { const pr = chrome.tabs.remove(tabId); if (pr && pr.catch) pr.catch(() => {}); } catch (e) {}
        triggerAnchorFallback(url);
      }
    });
  });
}

if (typeof chrome !== 'undefined' && chrome.downloads && chrome.downloads.onCreated) {
  chrome.downloads.onCreated.addListener((item) => {
    const w = watchByUrl.get(item.url);
    if (w) {
      if (w.timer) clearTimeout(w.timer);
      watchByUrl.delete(item.url);
      diagLog('WATCH matched id=' + item.id + ' file=' + w.filename);
      trackDownload(item.id, {
        tabId: w.tabId, frameId: w.frameId, filename: w.filename,
        url: item.url, via: 'blob', fallbackTried: true, blobUrl: null,
        key: w.key || ''
      });
      return;
    }
    // An anchor download (instant path): the navigation became a
    // download. Claim it so its completion is toasted honestly.
    const pa = pendingAnchors.get(item.url);
    if (pa) {
      if (pa.timer) clearTimeout(pa.timer);
      pendingAnchors.delete(item.url);
      // NOTE: lastAnchorName is deliberately NOT cleared here —
      // onDeterminingFilename fires around creation time, after this
      // handler, and the recency fallback needs it. The 20 s window
      // in the fallback is the expiry guard.
      diagLog('ANCHOR matched id=' + item.id + ' file=' + pa.filename);
      // The anchor opened target=_blank: close its blank tab if it
      // is still hanging around (Chrome usually closes it itself).
      if (pa.blankTabId) {
        const bid = pa.blankTabId;
        setTimeout(() => {
          try {
            chrome.tabs.get(bid, (t) => {
              if (chrome.runtime.lastError || !t) return;
              if (!t.url || t.url === 'about:blank') {
                try { const p = chrome.tabs.remove(bid); if (p && p.catch) p.catch(() => {}); } catch (e) {}
              }
            });
          } catch (e) {}
        }, 1500);
      }
      clearAnchorFilenameRule();
      trackDownload(item.id, {
        tabId: pa.tabId, frameId: pa.frameId, filename: pa.filename,
        url: item.url, via: 'anchor', fallbackTried: false, blobUrl: null,
        key: pa.key || ''
      });
    }
  });
}

// downloadId -> {tabId, frameId, filename, url, via, fallbackTried, blobUrl}
const pendingDownloads = new Map();

function sendToast(tabId, frameId, text) {
  if (typeof tabId !== 'number' || tabId < 0) return;
  try {
    const opts = (typeof frameId === 'number' && frameId >= 0) ? { frameId } : undefined;
    const p = opts
      ? chrome.tabs.sendMessage(tabId, { type: 'MT_TOAST', text }, opts)
      : chrome.tabs.sendMessage(tabId, { type: 'MT_TOAST', text });
    if (p && p.catch) p.catch(() => {}); // frame gone — ignore
  } catch (e) { /* tab gone — ignore */ }
}

function mapDownloadError(code) {
  switch (code) {
    case 'FILE_FAILED': return 'the file wasn\'t available on the site';
    case 'NETWORK_FAILED': return 'the connection was lost';
    case 'USER_CANCELED': return 'cancelled';
    case 'FILE_TOO_LARGE': return 'the file is too large';
    case 'FILE_NAME_TOO_LONG': return 'the file name is too long';
    default: return code ? ('server error (' + code + ')') : 'unknown error';
  }
}

function trackDownload(downloadId, info) {
  pendingDownloads.set(downloadId, info);
}

function forgetDownload(downloadId) {
  const p = pendingDownloads.get(downloadId);
  if (p && p.url) unmarkOwnDownload(p.url);
  pendingDownloads.delete(downloadId);
}

if (typeof chrome !== 'undefined' && chrome.downloads && chrome.downloads.onChanged) {
  chrome.downloads.onChanged.addListener((delta) => {
    const p = pendingDownloads.get(delta.id);
    if (!p) {
      // Untracked completion (the worker restarted mid-download):
      // nothing to recover — v1.7 keeps no records, and the next
      // click re-checks the browser's download history by URL.
      return;
    }
    if (delta.state && delta.state.current === 'complete') {
      if (p.key) markSaved(p.key, delta.id);
      sendToast(p.tabId, p.frameId, 'Saved.');
      forgetDownload(delta.id);
      return;
    }
    if (delta.error && delta.error.current) {
      // The user cancelled the download — including dismissing the
      // Save dialog ("Ask where to save each time"). Never retry
      // that: cancelling must mean nothing downloads. Release the
      // guard so a later click can try again.
      if (delta.error.current === 'USER_CANCELED') {
        if (p.key) releaseSave(p.key);
        sendToast(p.tabId, p.frameId, 'Save cancelled.');
        forgetDownload(delta.id);
        return;
      }
      // Direct/anchor download failed — retry once through the page
      // fetch (the page context is the only one signed video URLs
      // accept).
      if ((p.via === 'direct' || p.via === 'anchor') && !p.fallbackTried) {
        p.fallbackTried = true;
        sendToast(p.tabId, p.frameId, 'Retrying…');
        try {
          const opts = (typeof p.frameId === 'number' && p.frameId >= 0) ? { frameId: p.frameId } : undefined;
          const pr = opts
            ? chrome.tabs.sendMessage(p.tabId, { type: 'MT_FETCH_TRANSFER', url: p.url, filename: p.filename }, opts)
            : chrome.tabs.sendMessage(p.tabId, { type: 'MT_FETCH_TRANSFER', url: p.url, filename: p.filename });
          if (pr && pr.then) {
            pr.then((res) => {
              if (res && res.ok) {
                // New download started via the transfer path; it is
                // tracked under its own id — drop the old entry.
                pendingDownloads.delete(delta.id);
              } else if (res && res.anchor) {
                sendToast(p.tabId, p.frameId, 'Saving started — check your Downloads folder.');
                pendingDownloads.delete(delta.id);
              } else {
                releaseSave(p.key);
                sendToast(p.tabId, p.frameId, 'Save failed: the file wasn\'t available on the site — please try again.');
                pendingDownloads.delete(delta.id);
              }
            }).catch(() => {
              releaseSave(p.key);
              sendToast(p.tabId, p.frameId, 'Save failed: the file wasn\'t available on the site — please try again.');
              pendingDownloads.delete(delta.id);
            });
          } else {
            releaseSave(p.key);
            pendingDownloads.delete(delta.id);
          }
        } catch (e) {
          releaseSave(p.key);
          sendToast(p.tabId, p.frameId, 'Save failed: the file wasn\'t available on the site — please try again.');
          pendingDownloads.delete(delta.id);
        }
        return;
      }
      if (p.key) releaseSave(p.key);
      sendToast(p.tabId, p.frameId, 'Save failed: ' + mapDownloadError(delta.error.current));
      forgetDownload(delta.id);
    }
  });
}

/* Inject content.js into every open http(s) tab. Per-tab failures
   (restricted pages, tabs still loading, etc.) are swallowed — one
   bad tab must never stop the rest. */
async function injectIntoOpenTabs() {
  let tabs = [];
  try {
    tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
  } catch (e) {
    return;
  }
  for (const tab of tabs) {
    if (!tab || typeof tab.id !== 'number') continue;
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        files: ['content.js']
      });
    } catch (e) {
      /* restricted tab / tab gone — ignore and move on */
    }
  }
}

chrome.runtime.onInstalled.addListener(() => { injectIntoOpenTabs(); });
chrome.runtime.onStartup.addListener(() => { injectIntoOpenTabs(); });

// Test hook (also lets the worker be poked from the service-worker
// console): re-runs the open-tab injection on demand.
globalThis.__mtInject = injectIntoOpenTabs;

/* ---------- offscreen merge document (ffmpeg.wasm, v1.7) ---------- */

// The offscreen document runs bundled ffmpeg.wasm 0.12 (single-
// threaded, no SharedArrayBuffer needed) and merges separate video +
// audio streams — or an HLS/DASH manifest — into one mp4 with
// -c copy (no re-encode). It is created once and reused across merges.
let offscreenReady = null;
async function ensureOffscreen() {
  if (offscreenReady) return offscreenReady;
  offscreenReady = (async () => {
    try {
      if (await chrome.offscreen.hasDocument()) return true;
      await chrome.offscreen.createDocument({
        url: 'offscreen.html',
        reasons: ['WORKERS', 'BLOBS'],
        justification: 'Merge separate video and audio streams into one playable mp4 with bundled ffmpeg.wasm, without re-encoding.'
      });
      return true;
    } catch (e) {
      diagLog('offscreen create failed: ' + ((e && e.message) || e));
      offscreenReady = null;
      return false;
    }
  })();
  return offscreenReady;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== 'string') return false;

  // Content script asking: what media was fetched while THIS video
  // was playing? `since` is the epoch ms the video element started
  // playing. The tab-global best (v1.6) is gone: on feed pages it
  // regularly returned a DIFFERENT video's URL.
  if (msg.type === 'MT_BEST_FOR_VIDEO') {
    const tabId = sender && sender.tab ? sender.tab.id : null;
    const best = (typeof tabId === 'number') ? bestMediaForVideo(tabId, msg.since) : null;
    if (best) sendResponse({ ok: true, ...best });
    else sendResponse({ ok: true, bestMp4: null, bestSize: 0, stream: null, fresh: false, seenAt: 0, mime: '' });
    return false;
  }

  // Content script about to start an anchor download of a blob URL:
  // watch for it so its completion can be toasted honestly.
  if (msg.type === 'MT_WATCH') {
    const tabId = sender && sender.tab ? sender.tab.id : -1;
    const frameId = sender && typeof sender.frameId === 'number' ? sender.frameId : -1;
    if (typeof msg.url === 'string' && typeof msg.filename === 'string') {
      watchDownload(msg.url, applyFolder(msg.filename), tabId, frameId, (typeof msg.key === 'string' ? msg.key : ''));
      sendResponse({ ok: true });
    } else {
      sendResponse({ ok: false, error: 'bad watch' });
    }
    return false;
  }

  // Content script about to anchor-click a video URL: register the
  // filename (for onDeterminingFilename) and watch for the download.
  // The net-request rules turn the navigation into a download; if no
  // download appears within ANCHOR_WATCH_MS, the watchdog closes any
  // stray tab and falls back to the fetch path. Before replying, a
  // dynamic rule is installed that names the file correctly in the
  // response itself (onDeterminingFilename does not fire for
  // navigation downloads, so the name cannot be fixed there).
  if (msg.type === 'MT_ANCHOR') {
    const tabId = sender && sender.tab ? sender.tab.id : -1;
    const frameId = sender && typeof sender.frameId === 'number' ? sender.frameId : -1;
    if (typeof msg.url === 'string' && typeof msg.filename === 'string') {
      const key = (typeof msg.key === 'string' && msg.key) ? msg.key : keyForUrl(msg.url);
      // Folder prefix (if set in the popup) applies to the rule's
      // filename, the watch entry and the guard record alike.
      const filename = applyFolder(msg.filename);
      const register = () => {
        // The anchor navigation/download re-fetches this URL — mark it
        // so the observer does not mistake the download for the
        // player's fetch (own-download exclusion).
        markOwnDownload(msg.url);
        rememberNameForUrl(msg.url, filename);
        lastAnchorName = { filename: filename, at: Date.now() };
        const old = pendingAnchors.get(msg.url);
        if (old && old.timer) clearTimeout(old.timer);
        const entry = { tabId, frameId, filename: filename, url: msg.url, key, at: Date.now(), fallbackSent: false, blankTabId: null, blankTabCandidate: false, timer: null };
        entry.timer = setTimeout(() => triggerAnchorFallback(msg.url), ANCHOR_WATCH_MS);
        pendingAnchors.set(msg.url, entry);
        setAnchorFilenameRule(msg.url, filename).then(() => {
          sendResponse({ ok: true, key });
        }).catch(() => sendResponse({ ok: true, key }));
      };
      // force=true: the user chose "Download again" in the confirm
      // prompt — bypass the duplicate guard for this one click.
      if (msg.force === true) {
        reserveSave(key, { filename: filename, url: msg.url });
        register();
      } else {
        checkDuplicate(key, msg.url).then((dup) => {
          if (dup.dup) {
            sendResponse({ ok: false, dup: dup.state });
            return;
          }
          reserveSave(key, { filename: filename, url: msg.url });
          register();
        }).catch(() => register()); // fail-open: never block a first save
      }
      return true; // async reply — the rule must be active first
    } else {
      sendResponse({ ok: false, error: 'bad anchor' });
    }
    return false;
  }

  // The page reports a save attempt finally failed (fetch path):
  // release the duplicate guard so the user can retry the video.
  if (msg.type === 'MT_RELEASE' && typeof msg.key === 'string') {
    releaseSave(msg.key);
    sendResponse({ ok: true });
    return false;
  }

  // Fetch a URL in the page's MAIN world (chrome.scripting,
  // world:'MAIN') and return a blob URL for it. The MAIN world is the
  // fallback when the content script's isolated-world fetch fails.
  // Only a blob URL string crosses back — ArrayBuffers cannot cross
  // the extension-message boundary.
  if (msg.type === 'MT_FETCH_MAIN' && typeof msg.url === 'string') {
    const tabId = sender && sender.tab ? sender.tab.id : -1;
    const frameId = sender && typeof sender.frameId === 'number' ? sender.frameId : 0;
    chrome.scripting.executeScript({
      target: { tabId, frameIds: [frameId] },
      world: 'MAIN',
      func: async (url) => {
        try {
          const r = await fetch(url);
          if (!r.ok) return { ok: false, status: r.status };
          const b = await r.arrayBuffer();
          if (!b || b.byteLength === 0) return { ok: false, error: 'empty' };
          const blobUrl = URL.createObjectURL(new Blob([b], { type: 'video/mp4' }));
          setTimeout(() => { try { URL.revokeObjectURL(blobUrl); } catch (e) {} }, 120000);
          return { ok: true, blobUrl, bytes: b.byteLength };
        } catch (e) { return { ok: false, error: String((e && e.message) || e) }; }
      },
      args: [msg.url]
    }).then((results) => {
      const r = results && results[0] ? results[0].result : null;
      sendResponse(r || { ok: false, error: 'no result' });
    }).catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true; // async reply
  }

  // Click an anchor for a MAIN-world blob URL, in the MAIN world
  // (the blob was created there).
  if (msg.type === 'MT_ANCHOR_MAIN' && typeof msg.blobUrl === 'string') {
    const tabId = sender && sender.tab ? sender.tab.id : -1;
    const frameId = sender && typeof sender.frameId === 'number' ? sender.frameId : 0;
    chrome.scripting.executeScript({
      target: { tabId, frameIds: [frameId] },
      world: 'MAIN',
      func: (blobUrl, filename) => {
        try {
          const a = document.createElement('a');
          a.href = blobUrl; a.download = filename; a.style.display = 'none';
          document.documentElement.appendChild(a); a.click(); a.remove();
          return { ok: true };
        } catch (e) { return { ok: false, error: String((e && e.message) || e) }; }
      },
      args: [msg.blobUrl, applyFolder(msg.filename || 'video.mp4')]
    }).then((results) => {
      const r = results && results[0] ? results[0].result : null;
      sendResponse(r || { ok: false, error: 'no result' });
    }).catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true; // async reply
  }

  // Read YouTube's progressive formats from the page's own player
  // response (window.ytplayer.bootstrapPlayerResponse, MAIN world —
  // the isolated world cannot see page globals). Returns only
  // progressive mp4 formats that carry a direct URL (itag 18/22
  // when the video has them), best (tallest) first. Most videos
  // have none — YouTube serves SABR/UMP only — and then the list
  // is empty and the caller shows the honest stream message.
  if (msg.type === 'MT_YT_FORMATS') {
    const tabId = sender && sender.tab ? sender.tab.id : -1;
    const frameId = sender && typeof sender.frameId === 'number' ? sender.frameId : 0;
    chrome.scripting.executeScript({
      target: { tabId, frameIds: [frameId] },
      world: 'MAIN',
      func: () => {
        try {
          let bpr = window.ytplayer && window.ytplayer.bootstrapPlayerResponse;
          if (typeof bpr === 'string') { try { bpr = JSON.parse(bpr); } catch (e) { return { ok: false, error: 'bad player response' }; } }
          if (!bpr || !bpr.streamingData) return { ok: true, formats: [] };
          const out = [];
          const list = bpr.streamingData.formats || [];
          for (const f of list) {
            if (!f || !f.url || typeof f.mimeType !== 'string') continue;
            if (f.mimeType.indexOf('video/mp4') !== 0) continue;
            out.push({ itag: f.itag || 0, mime: f.mimeType.split(';')[0], url: f.url, w: f.width || 0, h: f.height || 0, q: f.qualityLabel || '' });
          }
          out.sort((a, b) => (b.h || 0) - (a.h || 0));
          return { ok: true, formats: out };
        } catch (e) { return { ok: false, error: String((e && e.message) || e) }; }
      }
    }).then((results) => {
      const r = results && results[0] ? results[0].result : null;
      diagLog('MT_YT_FORMATS formats=' + ((r && r.formats) ? r.formats.length : 'err:' + ((r && r.error) || 'no result')));
      sendResponse(r || { ok: false, error: 'no result' });
    }).catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true; // async reply
  }

  // Read YouTube's ADAPTIVE formats. First try: the page's own player
  // response (MAIN world). Second try: YouTube's player API with the
  // ANDROID client — the browser's WEB player response carries NO
  // stream URLs at all any more (SABR/UMP only: 36 formats, zero
  // `url` fields, no HLS/DASH manifest — proven 2026-11-23), while
  // the ANDROID client returns all 36 formats WITH direct googlevideo
  // URLs (incl. progressive itag 18). The player API is YouTube's own
  // endpoint (the page itself calls it); the key below is the public
  // web client key embedded in every YouTube page, not a secret.
  // Returns progressive mp4s, best video-only mp4 candidates and the
  // best audio-only m4a, for the offscreen merge. A candidate whose
  // URL is actually an HLS manifest (itag 311) is skipped later by
  // the offscreen prober — the list is best-first, so the merge just
  // takes the first real mp4.
  if (msg.type === 'MT_YT_ADAPTIVE') {
    const tabId = sender && sender.tab ? sender.tab.id : -1;
    const frameId = sender && typeof sender.frameId === 'number' ? sender.frameId : 0;
    const videoId = (typeof msg.videoId === 'string' && msg.videoId) ? msg.videoId : '';
    const parseStreamingData = (sd) => {
      const out = { progressive: [], videoOnly: [], audioOnly: null };
      if (!sd) return out;
      for (const f of (sd.formats || [])) {
        if (!f || !f.url || typeof f.mimeType !== 'string') continue;
        if (f.mimeType.indexOf('video/mp4') !== 0) continue;
        out.progressive.push({ itag: f.itag || 0, mime: f.mimeType.split(';')[0], url: f.url, w: f.width || 0, h: f.height || 0, q: f.qualityLabel || '' });
      }
      out.progressive.sort((a, b) => (b.h || 0) - (a.h || 0));
      for (const f of (sd.adaptiveFormats || [])) {
        if (!f || !f.url || typeof f.mimeType !== 'string') continue;
        const mime = f.mimeType.split(';')[0];
        if (mime === 'video/mp4' && !f.audioQuality) {
          out.videoOnly.push({ itag: f.itag || 0, mime, url: f.url, w: f.width || 0, h: f.height || 0, q: f.qualityLabel || '' });
        } else if (mime === 'audio/mp4') {
          const br = f.bitrate || 0;
          if (!out.audioOnly || br > (out.audioOnly.bitrate || 0)) {
            out.audioOnly = { itag: f.itag || 0, mime, url: f.url, bitrate: br };
          }
        }
      }
      out.videoOnly.sort((a, b) => (b.h || 0) - (a.h || 0));
      return out;
    };
    const usable = (o) => o && (o.progressive.length > 0 || (o.videoOnly.length > 0 && o.audioOnly));
    const finish = (o, via) => {
      diagLog('MT_YT_ADAPTIVE via=' + via + ' prog=' + o.progressive.length + ' vid=' + o.videoOnly.length + ' aud=' + (o.audioOnly ? 'yes' : 'no'));
      sendResponse({ ok: true, progressive: o.progressive, videoOnly: o.videoOnly, audioOnly: o.audioOnly });
    };
    const tryPlayerApi = async () => {
      // NOTE: the player API was tried from this worker first and is
      // answered 403 (the worker's origin is chrome-extension://, not
      // youtube.com — proven 2026-11-23). The content script makes
      // the same call from the page instead (same origin, 200), so
      // there is nothing useful to do here — return the empty result
      // and let the caller fall back to its own player-API call.
      diagLog('MT_YT_ADAPTIVE page response has no usable URLs — caller falls back to its own player-API call');
      finish({ progressive: [], videoOnly: [], audioOnly: null }, 'page-empty');
    };
    chrome.scripting.executeScript({
      target: { tabId, frameIds: [frameId] },
      world: 'MAIN',
      func: () => {
        try {
          let bpr = window.ytplayer && window.ytplayer.bootstrapPlayerResponse;
          if (typeof bpr === 'string') { try { bpr = JSON.parse(bpr); } catch (e) { return { ok: false, error: 'bad player response' }; } }
          if (!bpr || !bpr.streamingData) return { ok: true, streamingData: null };
          return { ok: true, streamingData: bpr.streamingData };
        } catch (e) { return { ok: false, error: String((e && e.message) || e) }; }
      }
    }).then((results) => {
      const r = results && results[0] ? results[0].result : null;
      if (r && r.ok && r.streamingData) {
        const o = parseStreamingData(r.streamingData);
        if (usable(o)) { finish(o, 'page'); return; }
        diagLog('MT_YT_ADAPTIVE page response has no usable URLs — trying player API');
      } else {
        diagLog('MT_YT_ADAPTIVE page response unavailable — trying player API');
      }
      tryPlayerApi();
    }).catch(() => tryPlayerApi());
    return true; // async reply
  }

  // The visitor pasted a YouTube link on the Save Video website and
  // the site asked the extension to save it. Open the video in a
  // background tab (the player API must run in a youtube.com tab's
  // MAIN world — the worker's own call is 403, and the site page is
  // the wrong origin), trigger the same save the on-page button runs,
  // and close the tab when the merge finishes (see MT_MERGE below).
  // Replies once the save has STARTED in the tab, not when the file
  // finishes downloading — the merge can take a minute on long videos.
  if (msg.type === 'MT_SITE_YT_SAVE') {
    const siteTabId = sender && sender.tab ? sender.tab.id : -1;
    const videoId = (typeof msg.videoId === 'string' && /^[A-Za-z0-9_-]{6,}$/.test(msg.videoId)) ? msg.videoId : '';
    if (!videoId) { sendResponse({ ok: false, error: 'bad videoId' }); return false; }
    chrome.tabs.create({ url: 'https://www.youtube.com/watch?v=' + videoId, active: false }, (tab) => {
      if (!tab || typeof tab.id !== 'number') { sendResponse({ ok: false, error: 'could not open tab' }); return; }
      const ytTabId = tab.id;
      siteYtTabs.set(ytTabId, siteTabId);
      diagLog('MT_SITE_YT_SAVE tab=' + ytTabId + ' video=' + videoId);
      let done = false;
      const finish = (res) => {
        if (done) return; done = true;
        if (!res || !res.ok) closeSiteYtTab(ytTabId);
        sendResponse(res || { ok: false, error: 'unknown' });
      };
      const tryTrigger = (left, reloaded) => {
        chrome.tabs.sendMessage(ytTabId, { type: 'MT_TRIGGER_YT_SAVE' }, (res) => {
          if (chrome.runtime.lastError || !res || !res.ok) {
            const err = (chrome.runtime.lastError && chrome.runtime.lastError.message) || (res && res.error) || 'no answer';
            diagLog('MT_SITE_YT_SAVE trigger fail (' + left + ' left, reloaded=' + reloaded + '): ' + String(err).slice(0, 220));
            if (left > 0) { setTimeout(() => tryTrigger(left - 1, reloaded), 2000); return; }
            if (!reloaded) {
              // One reload: a fresh load gets a fresh egress IP (a 429 /
              // sorry page answers nothing) and restarts slow metadata.
              diagLog('MT_SITE_YT_SAVE reloading tab once');
              try { chrome.tabs.reload(ytTabId, {}, function () { setTimeout(() => tryTrigger(15, true), 4000); }); }
              catch (e) { setTimeout(() => tryTrigger(15, true), 4000); }
              return;
            }
            finish({ ok: false, error: err });
            return;
          }
          diagLog('MT_SITE_YT_SAVE trigger ok');
          finish({ ok: true });
        });
      };
      const onUpdated = (id, info) => {
        if (id === ytTabId && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(onUpdated);
          diagLog('MT_SITE_YT_SAVE tab loaded, triggering');
          setTimeout(startTrigger, 3000);
        }
      };
      chrome.tabs.onUpdated.addListener(onUpdated);
      // The trigger chain must start exactly once: the 60s fallback
      // below exists only in case onUpdated never fires (the tab
      // loaded before the listener attached). Without this guard it
      // started a SECOND chain while the first was mid-reload, and
      // the two chains interleaved their retries.
      let triggerStarted = false;
      function startTrigger() { if (triggerStarted) return; triggerStarted = true; tryTrigger(15, false); }
      setTimeout(() => { chrome.tabs.onUpdated.removeListener(onUpdated); if (!done) startTrigger(); }, 60000);
      // Safety: never leave the tab open forever.
      setTimeout(() => { closeSiteYtTab(ytTabId); }, 10 * 60 * 1000);
    });
    return true; // async reply
  }

  // Merge separate streams in the offscreen document (MT_MERGE_REQUEST).
  // The offscreen doc fetches the bytes, muxes with ffmpeg.wasm and
  // saves via an in-document anchor click; this worker only reserves
  // the duplicate guard and forwards the result. `key` is the video
  // identity (the content script passes 'yt:<videoId>' for YouTube,
  // where the googlevideo path is the same for every video).
  if (msg.type === 'MT_MERGE') {
    const tabId = sender && sender.tab ? sender.tab.id : -1;
    const frameId = sender && typeof sender.frameId === 'number' ? sender.frameId : -1;
    const key = (typeof msg.key === 'string' && msg.key) ? msg.key : keyForUrl(msg.videoUrl || msg.manifestUrl || '');
    const filename = applyFolder(typeof msg.filename === 'string' && msg.filename ? msg.filename : 'video.mp4');
    const mediaUrl = msg.videoUrl || msg.manifestUrl || '';
    const startMerge = async () => {
      try {
        // The offscreen doc fetches these URLs itself — mark them so
        // the observer does not mistake the merge's fetches for the
        // player's (own-download exclusion).
        (Array.isArray(msg.videoCandidates) ? msg.videoCandidates : []).forEach((c) => { if (c && c.url) markOwnDownload(c.url); });
        if (msg.audioUrl) markOwnDownload(msg.audioUrl);
        if (msg.manifestUrl) markOwnDownload(msg.manifestUrl);
        const ok = await ensureOffscreen();
        if (!ok) { sendResponse({ ok: false, error: 'offscreen unavailable' }); return; }
        const res = await chrome.runtime.sendMessage({
          type: 'MT_MERGE_REQUEST',
          videoCandidates: Array.isArray(msg.videoCandidates) ? msg.videoCandidates : [],
          audioUrl: msg.audioUrl || null,
          audioItag: msg.audioItag || 0,
          manifestUrl: msg.manifestUrl || null,
          filename, key, tabId, frameId
        });
        if (res && res.ok) {
          // The offscreen doc registered the watch; the download is
          // tracked under its own id and marked 'saved' on completion.
          sendResponse({ ok: true, bytes: res.bytes });
          // A tab opened for a site-pasted YouTube video is done:
          // close it now that the merge finished (the download itself
          // runs in the offscreen doc, so closing the tab is safe).
          closeSiteYtTab(tabId);
        } else {
          releaseSave(key);
          sendResponse({ ok: false, error: (res && res.error) || 'merge failed' });
          closeSiteYtTab(tabId);
        }
      } catch (e) {
        releaseSave(key);
        sendResponse({ ok: false, error: String((e && e.message) || e) });
        closeSiteYtTab(tabId);
      }
    };
    if (msg.force === true) {
      reserveSave(key, { filename, url: mediaUrl });
      startMerge();
    } else {
      checkDuplicate(key, mediaUrl).then((dup) => {
        if (dup.dup) { sendResponse({ ok: false, dup: dup.state }); return; }
        reserveSave(key, { filename, url: mediaUrl });
        startMerge();
      }).catch(() => { reserveSave(key, { filename, url: mediaUrl }); startMerge(); });
    }
    return true; // async reply
  }

  // Fresh googlevideo URL for one YouTube stream (same videoId +
  // itag). The offscreen merge asks for this when a chunk 403s:
  // googlevideo serves only ~6 MB per URL, then 403s the next
  // request (proven 2026-11-23 — not IP rotation, not a request
  // count; a fresh player-API URL serves another ~6 MB). The player
  // API call runs in the tab's MAIN world (same origin as the page
  // — the worker's own call is 403, proven 2026-11-23) with the
  // ANDROID client, exactly like the content script's
  // fetchYtPlayerApi. The fresh URL is marked as an own-download so
  // the observer never mistakes the merge's fetches for the
  // player's.
  if (msg.type === 'MT_REFRESH_URL') {
    const tabId = (typeof msg.tabId === 'number') ? msg.tabId : -1;
    const frameId = (typeof msg.frameId === 'number') ? msg.frameId : 0;
    const videoId = (typeof msg.videoId === 'string' && msg.videoId) ? msg.videoId : '';
    const itag = (typeof msg.itag === 'number') ? msg.itag : 0;
    if (!videoId || !itag) { sendResponse({ ok: false, error: 'no videoId/itag' }); return false; }
    chrome.scripting.executeScript({
      target: { tabId, frameIds: [frameId] },
      world: 'MAIN',
      func: (vid, wantedItag) => {
        return fetch('https://www.youtube.com/youtubei/v1/player?key=AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8&prettyPrint=false', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ context: { client: { clientName: 'ANDROID', clientVersion: '20.10.38', androidSdkVersion: 30 } }, videoId: vid })
        }).then((r) => r.json()).then((j) => {
          const list = (j && j.streamingData) ? ((j.streamingData.adaptiveFormats || []).concat(j.streamingData.formats || [])) : [];
          for (const f of list) {
            if (f && f.itag === wantedItag && f.url) return { ok: true, url: f.url };
          }
          return { ok: false, error: 'itag not found' };
        }).catch((e) => ({ ok: false, error: String((e && e.message) || e) }));
      },
      args: [videoId, itag]
    }).then((results) => {
      const r = results && results[0] ? results[0].result : null;
      if (r && r.ok && r.url) {
        markOwnDownload(r.url);
        diagLog('MT_REFRESH_URL itag=' + itag + ' ok');
        sendResponse({ ok: true, url: r.url });
      } else {
        diagLog('MT_REFRESH_URL itag=' + itag + ' failed: ' + ((r && r.error) || 'no result'));
        sendResponse({ ok: false, error: (r && r.error) || 'no result' });
      }
    }).catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true; // async reply
  }

  // Progress from the offscreen merge -> toast on the tab that asked.
  if (msg.type === 'MT_MERGE_PROGRESS') {
    const tabId = (typeof msg.tabId === 'number') ? msg.tabId : -1;
    const frameId = (typeof msg.frameId === 'number') ? msg.frameId : -1;
    if (msg.stage === 'downloading') sendToast(tabId, frameId, 'Saving… ' + (msg.pct || 0) + '%');
    else if (msg.stage === 'merging') sendToast(tabId, frameId, 'Merging video and audio…');
    else if (msg.stage === 'loading') sendToast(tabId, frameId, 'Preparing…');
    return false;
  }

  // Fetch a URL as text in the page's MAIN world (same origin as the
  // page, so the site's own API/config endpoints answer). Used for
  // Vimeo's player config (request.files.progressive). Returns the
  // raw text; the caller parses it.
  if (msg.type === 'MT_FETCH_TEXT' && typeof msg.url === 'string') {
    const tabId = sender && sender.tab ? sender.tab.id : -1;
    const frameId = sender && typeof sender.frameId === 'number' ? sender.frameId : 0;
    chrome.scripting.executeScript({
      target: { tabId, frameIds: [frameId] },
      world: 'MAIN',
      func: async (url) => {
        try {
          const r = await fetch(url);
          if (!r.ok) return { ok: false, status: r.status };
          const t = await r.text();
          return { ok: true, text: t };
        } catch (e) { return { ok: false, error: String((e && e.message) || e) }; }
      },
      args: [msg.url]
    }).then((results) => {
      const r = results && results[0] ? results[0].result : null;
      sendResponse(r || { ok: false, error: 'no result' });
    }).catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true; // async reply
  }

  if (msg.type !== 'MT_SAVE' || typeof msg.url !== 'string') {
    return false;
  }
  const url = msg.url;
  // http(s) for ordinary videos; blob: for bytes the content script
  // fetched in the page (signed video URLs only work there).
  if (!/^https?:\/\//i.test(url) && !/^blob:/i.test(url)) {
    sendResponse({ ok: false, error: 'The link is not valid.' });
    return false;
  }
  const isBlob = /^blob:/i.test(url);
  const filename = applyFolder(typeof msg.filename === 'string' && msg.filename
    ? msg.filename
    : 'video.mp4');
  const tabId = sender && sender.tab ? sender.tab.id : -1;
  const frameId = sender && typeof sender.frameId === 'number' ? sender.frameId : -1;
  const key = (typeof msg.key === 'string' && msg.key) ? msg.key : keyForUrl(url);
  // A blob: URL is a fresh fetch of a video the guard already
  // reserved under its real URL — do not re-check it here (its blob
  // URL is unique per fetch and would never match).
  const startDirectDownload = () => {
    // The download manager re-fetches this URL — mark it so the
    // observer does not mistake the download for the player's fetch
    // (own-download exclusion). Blob URLs are never observed, so
    // only http(s) URLs are marked.
    if (!isBlob) markOwnDownload(url);
    // Store the intended name keyed by URL BEFORE starting the
    // download: onDeterminingFilename fires before the download
    // callback below, so the id-keyed name would arrive too late.
    rememberNameForUrl(url, filename);
    diagLog('MT_SAVE isBlob=' + isBlob + ' file=' + filename + ' saveAs=' + askCache + ' folder=' + (folderCache || 'Auto') + ' url=' + String(url).slice(0, 60));
    chrome.downloads.download(
      { url: url, filename: filename, saveAs: askCache, conflictAction: 'uniquify' },
      (downloadId) => {
        if (chrome.runtime.lastError) {
          if (!isBlob) releaseSave(key);
          sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        } else {
          // Remember the intended name so onDeterminingFilename can
          // suggest it even if the filename option above is dropped.
          rememberName(downloadId, filename);
          trackDownload(downloadId, {
            tabId, frameId, filename, url,
            via: isBlob ? 'blob' : 'direct',
            // A failed blob download has no retry: the blob is gone,
            // so a fresh click fetches the video again.
            fallbackTried: isBlob,
            blobUrl: null,
            key: isBlob ? '' : key
          });
          // Do NOT claim success here: the worker watches onChanged and
          // toasts "Saved." only when it really completes.
          sendResponse({ ok: true, id: downloadId, pending: true });
        }
      }
    );
  };
  if (!isBlob) {
    // force=true: the user chose "Download again" in the confirm
    // prompt — bypass the duplicate guard for this one click.
    if (msg.force === true) {
      reserveSave(key, { filename, url });
      startDirectDownload();
    } else {
      checkDuplicate(key, url).then((dup) => {
        if (dup.dup) {
          sendResponse({ ok: false, dup: dup.state });
          return;
        }
        reserveSave(key, { filename, url });
        startDirectDownload();
      }).catch(() => startDirectDownload()); // fail-open
    }
  } else {
    startDirectDownload();
  }
  return true; // keep the channel open for the async reply
});
