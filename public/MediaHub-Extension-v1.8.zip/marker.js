// MediaHub companion marker — lets the MediaHub website know this
// extension is installed, so the site hides its Install button.
// Runs at document_start on MediaHub pages only. Sets a plain DOM
// attribute; it reads nothing and sends nothing anywhere.
try { document.documentElement.setAttribute('data-mh-ext', '1'); } catch (e) {}
