// Save Video — offscreen document: merges separate video+audio streams (or an
// HLS/DASH manifest) into one playable mp4 with bundled ffmpeg.wasm,
// WITHOUT re-encoding (-c copy). Runs @ffmpeg/ffmpeg 0.12 on the
// single-threaded @ffmpeg/core 0.12 (no SharedArrayBuffer /
// cross-origin isolation needed — the 0.11 core required it and crashed
// with "pthread sent an error: memory access out of bounds", proven
// 2026-11-23). The core runs in a module worker created from a real
// extension URL (no blob: URLs — MV3 extension_pages CSP rejects them).
// The merged file is saved with an in-document anchor click on a blob
// URL (chrome.downloads is not available in offscreen documents, but
// the download attribute IS honoured for same-origin blob URLs —
// proven 2026-11-23: 24,523,481-byte YouTube merge saved, ffprobe
// h264 854x480 + aac, 487.48 s). The background registers the blob URL
// with MT_WATCH first, so the download is tracked and toasted honestly.
// No bytes are stored anywhere: FS files are deleted after each merge
// and the blob URL is revoked after the download starts.
import { FFmpeg } from './ffmpeg12/index.js';

let ffmpeg = null;
let ffmpegLoading = null;
let mergeBusy = false;

async function getFFmpeg() {
  if (ffmpeg) return ffmpeg;
  if (!ffmpegLoading) {
    ffmpegLoading = (async () => {
      const f = new FFmpeg();
      f.on('log', ({ message }) => {
        try { console.log('[MT-ffmpeg]', message); } catch (e) {}
      });
      await f.load({
        coreURL: chrome.runtime.getURL('ffmpeg12/ffmpeg-core.js'),
        wasmURL: chrome.runtime.getURL('ffmpeg12/ffmpeg-core.wasm')
      });
      ffmpeg = f;
      return f;
    })();
  }
  return ffmpegLoading;
}

function sendProgress(tabId, frameId, stage, pct) {
  try {
    chrome.runtime.sendMessage({ type: 'MT_MERGE_PROGRESS', tabId, frameId, stage, pct });
  } catch (e) { /* progress is best-effort */ }
}

// Fetch a URL with progress reports. Googlevideo (YouTube) answers
// 403 to a plain full GET for its adaptive URLs — proven 2026-11-23:
// plain GET 403 with any headers (Origin/UA/Referer irrelevant),
// ranged GET 206 always. Two more limits, both proven the same day:
// (a) a LARGE Range is also 403 — Range 0-2097151 (2 MB) returns
// 206 but 0-4194303 (4 MB) returns 403 — so chunks are 2 MB; (b) ONE
// URL serves only ~6 MB total, then 403s on the next request (3x
// 2 MB chunks 206, the 4th 403 — while the egress IP did NOT change
// and 6x 1 KB ranges on the same URL all 206, so it is neither IP
// rotation nor a request-count quota: it is a per-URL byte quota).
// So `refreshUrl`, when supplied, is called whenever a probe or a
// chunk gets a non-206: it must return a FRESH URL for the same
// stream (the background re-asks YouTube's player API for the same
// itag), and the failed chunk is retried from the same offset on
// the fresh URL. Each fresh URL buys another ~6 MB. Up to
// MAX_REFRESHES refreshes per file (a 66 MB video needs ~11).
// Every request carries cache:'no-store': Chrome's HTTP cache can
// answer a later Range request for the same URL with an earlier
// probe's 1-byte 206 (proven: a 7.9 MB range answered 206 with
// 1 byte), so no merge fetch may touch the cache. A server that
// answers 200 to a range request (Range ignored) returns the whole
// file at once — that is taken as-is. The Range header survives
// fetch's redirect following, and the redirect target honours it
// (206, proven).
const MAX_REFRESHES = 40;
async function fetchWithProgress(url, onPct, refreshUrl) {
  const errFor = (status) => new Error('fetch ' + status + ' for ' + url.slice(0, 80));
  let refreshes = 0;
  const refresh = async () => {
    if (!refreshUrl || refreshes >= MAX_REFRESHES) return null;
    refreshes++;
    try {
      const fresh = await refreshUrl();
      return (typeof fresh === 'string' && fresh) ? fresh : null;
    } catch (e) { return null; }
  };
  let probe = await fetch(url, { headers: { Range: 'bytes=0-0' }, cache: 'no-store' });
  if (probe.status !== 206 && probe.status !== 200) {
    const fresh = await refresh();
    if (!fresh) throw errFor(probe.status);
    url = fresh;
    probe = await fetch(url, { headers: { Range: 'bytes=0-0' }, cache: 'no-store' });
  }
  if (probe.status === 200) {
    // Server ignored the Range and sent the whole file.
    const buf = await probe.arrayBuffer();
    if (onPct) onPct(100);
    return new Uint8Array(buf);
  }
  if (probe.status !== 206) throw errFor(probe.status);
  const cr = probe.headers.get('content-range') || '';
  const m = cr.match(/\/(\d+)\s*$/);
  const total = m ? parseInt(m[1], 10) : 0;
  if (!total) {
    // No total advertised — fall back to a plain full fetch.
    const res = await fetch(url, { cache: 'no-store' });
    if (!res.ok) throw errFor(res.status);
    const buf = await res.arrayBuffer();
    if (onPct) onPct(100);
    return new Uint8Array(buf);
  }
  const CHUNK = 2 * 1024 * 1024; // 2 MB: googlevideo 206s 0-2097151 but 403s ranges >= ~4 MB
  const parts = [];
  let received = 0;
  for (let start = 0; start < total; start += CHUNK) {
    const end = Math.min(start + CHUNK - 1, total - 1);
    let r = await fetch(url, { headers: { Range: 'bytes=' + start + '-' + end }, cache: 'no-store' });
    if (r.status !== 206 && r.status !== 200) {
      // Per-URL byte quota exhausted — fresh URL, same chunk.
      const fresh = await refresh();
      if (!fresh) throw errFor(r.status);
      url = fresh;
      r = await fetch(url, { headers: { Range: 'bytes=' + start + '-' + end }, cache: 'no-store' });
    }
    if (r.status === 200) {
      // Whole file despite the Range — take it and stop.
      const buf = await r.arrayBuffer();
      if (onPct) onPct(100);
      return new Uint8Array(buf);
    }
    if (r.status !== 206) throw errFor(r.status);
    const buf = await r.arrayBuffer();
    parts.push(new Uint8Array(buf));
    received += buf.byteLength;
    if (onPct) onPct(Math.round((received / total) * 100));
  }
  const all = new Uint8Array(received);
  let off = 0;
  for (const c of parts) { all.set(c, off); off += c.length; }
  if (onPct) onPct(100);
  return all;
}

// Ask the background for a fresh googlevideo URL for the same
// YouTube stream (same videoId + itag). Returns the URL or null.
function requestFreshUrl(tabId, frameId, videoId, itag) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage(
        { type: 'MT_REFRESH_URL', tabId, frameId, videoId, itag },
        (res) => resolve((res && res.ok && res.url) ? res.url : null)
      );
    } catch (e) { resolve(null); }
  });
}

// A YouTube adaptive URL can be an HLS manifest instead of an mp4
// (itag 311 answered #EXTM3U, proven 2026-11-23). Probe the first
// kilobyte: a manifest is skipped, a real file is kept.
async function isHlsManifest(url) {
  try {
    const res = await fetch(url, { headers: { Range: 'bytes=0-1023' }, cache: 'no-store' });
    if (!res.ok) return false;
    const text = await res.text();
    return text.trimStart().startsWith('#EXTM3U');
  } catch (e) {
    return false;
  }
}

async function deleteQuiet(f, name) {
  try { await f.deleteFile(name); } catch (e) {}
}

// Merge request from the background worker:
// { videoCandidates: [{url, h}], audioUrl, manifestUrl, filename, key, tabId, frameId }
// - videoCandidates + audioUrl: separate mp4 + m4a streams (YouTube).
// - manifestUrl: an HLS (.m3u8) or DASH (.mpd) manifest to mux directly.
// Replies {ok:true, bytes} or {ok:false, error}.
async function handleMerge(msg, sendResponse) {
  if (mergeBusy) {
    sendResponse({ ok: false, error: 'busy' });
    return;
  }
  mergeBusy = true;
  const tabId = msg.tabId;
  const frameId = msg.frameId;
  try {
    const f = await getFFmpeg();
    sendProgress(tabId, frameId, 'loading', 0);
    let outName = 'out.mp4';
    if (msg.manifestUrl) {
      // HLS/DASH: ffmpeg reads the manifest itself (segments are
      // fetched by the wasm HTTP layer) and copies the streams.
      sendProgress(tabId, frameId, 'merging', 0);
      const ret = await f.exec(['-nostdin', '-y', '-i', msg.manifestUrl, '-c', 'copy', outName]);
      if (ret !== 0) throw new Error('ffmpeg merge failed (code ' + ret + ')');
    } else {
      // Separate streams: try each video candidate until one is a
      // real mp4 (not an HLS manifest), then fetch video + audio.
      // The refresh callback re-asks YouTube's player API for the
      // same itag when googlevideo's per-URL byte quota (~6 MB)
      // 403s a chunk — the videoId comes from the guard key
      // ('yt:<videoId>'), the itags from the candidate / message.
      const videoId = (typeof msg.key === 'string' && msg.key.indexOf('yt:') === 0) ? msg.key.slice(3) : '';
      let videoUrl = null;
      let videoItag = 0;
      const candidates = Array.isArray(msg.videoCandidates) ? msg.videoCandidates : [];
      for (const c of candidates) {
        if (!c || !c.url) continue;
        if (await isHlsManifest(c.url)) continue;
        videoUrl = c.url;
        videoItag = c.itag || 0;
        break;
      }
      if (!videoUrl) throw new Error('no playable video stream found');
      if (!msg.audioUrl) throw new Error('no audio stream found');
      sendProgress(tabId, frameId, 'downloading', 0);
      const videoRefresh = (videoId && videoItag) ? () => requestFreshUrl(tabId, frameId, videoId, videoItag) : null;
      const audioRefresh = (videoId && msg.audioItag) ? () => requestFreshUrl(tabId, frameId, videoId, msg.audioItag) : null;
      const video = await fetchWithProgress(videoUrl, (p) => sendProgress(tabId, frameId, 'downloading', Math.round(p * 0.7)), videoRefresh);
      const audio = await fetchWithProgress(msg.audioUrl, (p) => sendProgress(tabId, frameId, 'downloading', 70 + Math.round(p * 0.3)), audioRefresh);
      await f.writeFile('in-v.mp4', video);
      await f.writeFile('in-a.m4a', audio);
      sendProgress(tabId, frameId, 'merging', 0);
      const ret = await f.exec(['-nostdin', '-y', '-i', 'in-v.mp4', '-i', 'in-a.m4a', '-c', 'copy', '-shortest', outName]);
      if (ret !== 0) throw new Error('ffmpeg merge failed (code ' + ret + ')');
    }
    const data = await f.readFile(outName);
    if (!data || data.length === 0) throw new Error('merged file is empty');
    // Free the wasm FS copies now that the bytes are in JS memory.
    await deleteQuiet(f, 'in-v.mp4');
    await deleteQuiet(f, 'in-a.m4a');
    await deleteQuiet(f, outName);
    const blob = new Blob([data], { type: 'video/mp4' });
    const blobUrl = URL.createObjectURL(blob);
    // Register the watch BEFORE clicking, so the background tracks
    // this download and toasts "Saved." only when it completes.
    const watched = await new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(
          { type: 'MT_WATCH', url: blobUrl, filename: msg.filename, key: msg.key || '' },
          (res) => resolve(!!(res && res.ok))
        );
      } catch (e) { resolve(false); }
    });
    if (!watched) {
      URL.revokeObjectURL(blobUrl);
      throw new Error('could not register the download');
    }
    const a = document.createElement('a');
    a.href = blobUrl;
    a.download = msg.filename;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    a.remove();
    // The download manager reads the blob on its own schedule — keep
    // it alive a while, then revoke it so nothing is kept.
    setTimeout(() => { try { URL.revokeObjectURL(blobUrl); } catch (e) {} }, 120000);
    sendResponse({ ok: true, bytes: data.length });
  } catch (e) {
    sendResponse({ ok: false, error: String((e && e.message) || e) });
  } finally {
    mergeBusy = false;
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'MT_MERGE_REQUEST') return false;
  handleMerge(msg, sendResponse);
  return true; // async reply
});
