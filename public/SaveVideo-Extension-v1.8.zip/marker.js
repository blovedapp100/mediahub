// Save Video companion marker — lets the Save Video website know this
// extension is installed, so the site hides its Install button.
// Runs at document_start on Save Video pages only. Sets a plain DOM
// attribute; it reads nothing and sends nothing anywhere.
try { document.documentElement.setAttribute('data-mh-ext', '1'); } catch (e) {}
