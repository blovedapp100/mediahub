/* Save Video — content script.
   Shows a small save button on videos that are actually playing on the
   page (IDM-style). The button grabs the URL the browser is already
   playing and asks the background worker to save it at the best quality
   the site served — no quality menu, no extra requests, no data leaves
   the browser except the save itself.

   v1.1 fixes:
   - The button is position:fixed and positioned from the video's
     viewport rectangle. v1.0 wrapped the video in a new div and used
     an absolute button, which players like TikTok's xgplayer clip with
     overflow:hidden ancestors (and moving the <video> can break the
     player's own layout). Fixed positioning is immune to that, and the
     page DOM is never rearranged now.
   - Shadow-DOM-aware discovery: videos inside shadow roots are found
     and their roots are observed, so players that render inside a
     shadow tree are not missed.
   - Late src: the button is (re)checked on loadedmetadata, loadeddata,
     playing and loadstart, and when a video's src attribute changes,
     so players that set the source seconds after the first scan still
     get a button.
   - The background worker also injects this script into tabs that
     were already open at install time (Manifest V3 does not do that
     on its own), and the script guards against double-injection.

   v1.2 fixes:
   - URL resolution is async now: for blob/MSE playback it first asks
     the background worker (MT_BEST) for the largest media file this
     tab actually fetched (its webRequest observer saw the real
     Content-Length). The performance timeline cannot be trusted for
     sizes — cross-origin entries report 0 — which is how v1.1 saved
     a 194 KB TikTok logo clip instead of the real video.
   - The performance-timeline fallback now skips logo/splash/loading/
     brand/intro URLs and anything under 1 MB, and never saves a
     2-second clip as the video.

   v1.3 fixes:
   - TikTok's video CDN denies its signed URLs to any request outside
     the page context (Akamai 403 — proven live: page fetch 200 with
     the full bytes, extension fetch 403, plain curl 403; the signature
     itself is valid ~48h, so it is context, not expiry). So a signed
     video URL is now fetched HERE, in the page (page origin + cookies
     — the only context the CDN accepts), and its bytes are streamed
     to the background worker in 4 MB chunks, which saves them. Direct
     download stays the fast path for ordinary public mp4s, and a
     failed direct download retries automatically through this fetch.
   - Freshest URL wins: the background now reports whether its best
     observed URL was seen in the last 2 minutes.
   - Honest status: no "Saved." toast on start — the background
     toasts "Saved." only when the download really completes,
     and the real reason when it fails.

   v1.4 fixes (2026-11-21 — user's errors page + "late start"):
   - "Failed to fetch" on episode 4: the in-page fetch sent
     credentials:'include', but the video CDNs answer
     `Access-Control-Allow-Origin: *` WITHOUT
     `Access-Control-Allow-Credentials`, so a credentialed fetch fails
     CORS (proven live on the logo host: include -> "Failed to fetch",
     default/omit -> 200). The fetch now sends NO credentials — the
     signed URL itself carries all the authorisation the CDN needs —
     and falls back to a MAIN-world fetch when the isolated one fails.
   - Late start: v1.3 fetched the WHOLE file before the download
     appeared, with no feedback at all. Now (a) the button toasts
     "Saving…" the instant it is pressed, with % progress while the
     fallback fetch runs, and (b) the PRIMARY path is instant: an
     anchor click on the observed URL. On its own Chrome ignores the
     download attribute for cross-origin URLs (proven: _blank does
     nothing, no-target navigates the tab away), BUT the extension's
     declarativeNetRequest rules add `Content-Disposition: attachment`
     to main-frame navigations to the video CDNs, so the click starts
     a real download immediately (proven live: file in Downloads
     ~1 s after the click, page untouched). The background watches:
     if no download appears within 4 s, it closes any stray tab and
     falls back to the fetch path. The best URL is also warmed while
     the video plays, so the click needs no worker round trip.
   - All user-visible strings are now English.

   v1.5 fixes (2026-11-22 — duplicate downloads):
   - One video = one save. The background worker records each video
     (key = media URL without its query string) as 'downloading' when
     a save is accepted and 'saved' when it completes, persisted in
     chrome.storage.local so it survives a worker restart. A repeat
     click while a download is still running toasts
     "Already downloading." and starts nothing. A repeat click on an
     already-saved video shows a confirm prompt in the toast —
     "This file is already downloaded. Download again?" with
     [Download again] / [Cancel]; "Download again" bypasses the guard
     for that one click, Cancel (or ignoring the prompt) downloads
     nothing. A rapid double-click is also caught in the page itself.
     A failed attempt releases the record so a retry works.

   v1.6 fixes (2026-11-23 — all platforms):
   - The capture and save paths are site-agnostic: any progressive
     mp4 the page fetches (Facebook fbcdn, Instagram cdninstagram,
     TikTok, Pinterest pinimg, plain mp4 pages) is saved the same
     way — best observed file, instant anchor start, no-credentials
     fetch fallback. Signed-URL detection now covers the video CDNs
     of all those platforms (host + oh/oe/_nc_ params).
   - YouTube: the player serves SABR/UMP only — no progressive mp4
     in the player response, no direct adaptive URLs, and the
     observed videoplayback URL is not a file. So on youtube.com
     the button asks the background (MAIN world) for the page's own
     player response and saves the best progressive mp4 ONLY when
     one exists; otherwise it shows "No direct link for this video
     (stream/DRM format)." — never a fake or silent file.
   - Vimeo: the player lists progressive mp4s in its player config,
     so on vimeo.com the button fetches that config in the page
     context and saves the best progressive file. (Not verified on
     the real site yet — Vimeo's bot check blocks this test
     environment; the parsing is unit-tested.)
   - X / Reddit / Dailymotion are HLS/DASH-only: no single mp4
     exists to save, so they get the honest stream message too.
   - Instagram serves DASH byte-ranges (bytestart/byteend): a single
     range is an unplayable fragment, so the range params are
     stripped — the bare URL serves the whole file (ftyp+moov).
   - The saved filename keeps the video's container extension
     (.webm when the observed file really is WebM).
   - Download folder (popup setting): the folder name is cached
     here too (storage.local at load + onChanged), and prepended
     to the filename in onSaveClick — so the fetch-blob anchor in
     this page also lands in Downloads/<folder>/, exactly like the
     background paths. Empty = Auto (Downloads root).

   v1.7 fixes (2026-11-23 — wrong video + no stored data + merge):
   - WRONG VIDEO: the tab-global "largest mp4 wins" resolution
     downloaded a DIFFERENT video on feed pages (several videos
     preload at once). A button now resolves the URL for ITS video
     only: the element's own currentSrc/<source>, else the mp4 first
     observed while THAT video is playing (MT_BEST_FOR_VIDEO, timed
     to the element's play start), else the platform resolver for
     that video (Facebook reel id, YouTube player response). If no
     URL can be tied to the playing video with confidence, the honest
     "couldn't find" toast is shown — a wrong file is worse than no
     file. The performance-timeline fallback is gone: it was
     tab-global too, and it is how the wrong file got picked.
   - NO DATA SAVED: the duplicate guard keeps no persisted records
     (no mt_saved, no filename matching, no session storage). The
     in-progress record lives in the worker's memory only, and
     "already downloaded" is checked against the browser's own
     download history by video URL — never by title/filename, so two
     different videos with the same title both download.
   - Facebook: the reel plays via MSE with zero media requests, but
     the page HTML embeds videoDeliveryLegacyFields with a
     progressive browser_native_hd_url for that reel id — that is
     what is saved now.
   - YouTube: adaptive formats (video-only mp4 + audio m4a) are
     merged in an offscreen document with bundled ffmpeg.wasm
     (-c copy, no re-encode); progressive itag 18/22 still saves
     directly when present.

   Performance rules: no polling, no setInterval. MutationObserver
   (debounced) + IntersectionObserver only. Observers pause while the
   tab is hidden. At most 20 videos are tracked per page. */

(function () {
  'use strict';

  // Guard: the background worker may inject this script into a tab
  // where the manifest content script already ran (e.g. extension
  // update). Each extension has one isolated world per frame, so this
  // flag survives re-injection and prevents duplicate buttons.
  if (window.__mtLoaded) return;
  window.__mtLoaded = true;

  var MAX_VIDEOS = 20;
  var MIN_WIDTH = 200;
  var DEBOUNCE_MS = 300;
  var BTN_CLASS = 'mt-save-btn';
  var TOAST_ID = 'mt-toast';

  var enabled = true;
  var mo = null; // MutationObserver
  var io = null; // IntersectionObserver
  var debounceTimer = null;
  var rafPending = false;

  // video element -> { btn, inView }
  var tracked = new Map();
  // video element -> epoch ms when it last started playing. The
  // background's per-video URL resolution is timed to this moment:
  // only media whose fetch STARTED around/after it belongs to this
  // video (a feed preloads several videos at once — the tab-global
  // "largest mp4 wins" picked the wrong one, v1.7 fixes that).
  var playStartedAt = new Map();
  // Fallback anchor: epoch ms when a video element's src was last set.
  // The per-element 'playing' listener can miss the event when a
  // blob/MSE player sets src and calls play() in the same task (the
  // listener is attached only after the scan runs) — then
  // playStartedAt is 0 and the background falls back to tab-global
  // "largest wins", i.e. the WRONG video (proven 2026-11-23: vidB
  // resolved to vidA's f.mp4 because its accumulated total was
  // larger). The src-set time is a good proxy for the fetch start
  // (the fetch begins just before src is set), so it anchors the
  // window when the play event was missed.
  var srcSetAt = new Map();
  function getPlayStartedAt(video) {
    return playStartedAt.get(video) || srcSetAt.get(video) || 0;
  }
  // Roots already watched by the MutationObserver (document + shadow roots).
  var observedRoots = new Set();

  /* ---------- small helpers ---------- */

  function isHttpUrl(u) {
    return typeof u === 'string' && /^https?:\/\//i.test(u);
  }

  // A URL the browser is playing is a video by definition. Only stream
  // manifests (HLS/DASH) are not directly saveable as a file.
  function isSaveableVideoUrl(u) {
    if (!isHttpUrl(u)) return false;
    var low = u.split('?')[0].toLowerCase();
    if (low.endsWith('.m3u8') || low.endsWith('.mpd')) return false;
    return true;
  }

  function isStreamUrl(u) {
    if (!isHttpUrl(u)) return false;
    var low = u.split('?')[0].toLowerCase();
    return low.endsWith('.m3u8') || low.endsWith('.mpd');
  }

  // Score a candidate URL by resolution hints (1080p / 720p / size attrs).
  function resolutionScore(u, el) {
    var score = 0;
    var text = (u || '') + ' ' + [
      el ? el.getAttribute('data-quality') : '',
      el ? el.getAttribute('data-resolution') : '',
      el ? el.getAttribute('size') : '',
      el ? el.getAttribute('label') : ''
    ].join(' ');
    var m = text.match(/(\d{3,4})\s*p/i);
    if (m) score = parseInt(m[1], 10);
    var w = el ? parseInt(el.getAttribute('width') || '', 10) : NaN;
    if (!isNaN(w) && w > score) score = w;
    var h = el ? parseInt(el.getAttribute('height') || '', 10) : NaN;
    if (!isNaN(h) && h > score) score = h;
    return score;
  }

  function sanitizeFilename(base, ext) {
    var name = (base || 'video').replace(/[\\/:*?"<>|]/g, ' ').trim();
    name = name.replace(/\s+/g, ' ').slice(0, 80).trim();
    if (!name) name = 'video';
    var e = (ext === 'webm') ? 'webm' : 'mp4';
    return name + '.' + e;
  }

  // Container extension from an observed content-type: the file must
  // keep its real container (a WebM saved as .mp4 will not play).
  function mimeToExt(mime) {
    if (typeof mime === 'string' && mime.toLowerCase().indexOf('video/webm') === 0) return 'webm';
    return 'mp4';
  }

  // Video CDNs whose URLs are signed / context-bound (the direct
  // browser download of such a URL fails, so they must take the
  // instant anchor path from the page, like TikTok's).
  var VIDEO_CDN_RE = /fbcdn\.net|cdninstagram\.com|video\.twimg\.com|v\.redd\.it|googlevideo\.com|vod-progressive|dmcdn|pinimg\.com|dailymotion\.com|tiktokcdn/i;

  // Duplicate-guard key for a video: the media URL without its query
  // string (a signed URL's signature rotates, but the path is the
  // video). Must match keyForUrl() in background.js.
  function keyForUrl(u) {
    return (typeof u === 'string') ? u.split('?')[0] : '';
  }

  // Videos with a save attempt currently in flight (click -> anchor
  // click / direct-download call). A second click on the same video
  // while one is in flight is answered at once with
  // "Already downloading."; once the attempt is handed to the
  // background, the worker's persisted record guards further clicks.
  var savingVideos = new Set();

  /* ---------- toast ---------- */

  function toast(msg, holdMs) {
    var t = document.getElementById(TOAST_ID);
    if (!t) {
      t = document.createElement('div');
      t.id = TOAST_ID;
      t.style.cssText = 'position:fixed;left:50%;bottom:24px;transform:translateX(-50%);' +
        'background:rgba(0,0,0,0.85);color:#fff;font:14px Arial,sans-serif;' +
        'padding:10px 16px;border-radius:8px;z-index:2147483647;pointer-events:none;' +
        'max-width:80vw;text-align:center;box-shadow:0 2px 12px rgba(0,0,0,0.4);';
      document.documentElement.appendChild(t);
    }
    t.textContent = msg;
    t.style.opacity = '1';
    // A plain toast never has buttons: make sure a previous confirm
    // prompt cannot leave clickable buttons behind.
    t.style.pointerEvents = 'none';
    clearTimeout(t._mtTimer);
    t._mtTimer = setTimeout(function () { t.style.opacity = '0'; }, holdMs || 3500);
  }

  // Confirmation prompt built into the toast (never window.confirm):
  // "This file is already downloaded. Download again?" with two
  // buttons. onAgain runs when the user chooses to download again;
  // onCancel (or ignoring the prompt) downloads nothing. The prompt
  // auto-dismisses after 20 s if ignored.
  function confirmToast(msg, onAgain, onCancel) {
    var t = document.getElementById(TOAST_ID);
    if (!t) {
      t = document.createElement('div');
      t.id = TOAST_ID;
      t.style.cssText = 'position:fixed;left:50%;bottom:24px;transform:translateX(-50%);' +
        'background:rgba(0,0,0,0.85);color:#fff;font:14px Arial,sans-serif;' +
        'padding:10px 16px;border-radius:8px;z-index:2147483647;pointer-events:none;' +
        'max-width:80vw;text-align:center;box-shadow:0 2px 12px rgba(0,0,0,0.4);';
      document.documentElement.appendChild(t);
    }
    clearTimeout(t._mtTimer);
    while (t.firstChild) t.removeChild(t.firstChild);
    var span = document.createElement('span');
    span.textContent = msg;
    t.appendChild(span);
    function dismiss() {
      clearTimeout(t._mtTimer);
      t.style.pointerEvents = 'none';
      t.style.opacity = '0';
    }
    function mkBtn(label, primary, cb) {
      var b = document.createElement('button');
      b.type = 'button';
      b.textContent = label;
      b.className = 'mt-confirm-btn';
      b.setAttribute('data-mt-action', primary ? 'again' : 'cancel');
      b.style.cssText = 'margin-left:10px;padding:6px 12px;border:none;border-radius:6px;' +
        'cursor:pointer;font:14px Arial,sans-serif;' +
        (primary ? 'background:#0d9488;color:#fff;' : 'background:rgba(255,255,255,0.2);color:#fff;');
      b.addEventListener('click', function (ev) {
        ev.stopPropagation();
        dismiss();
        if (cb) cb();
      });
      return b;
    }
    t.appendChild(mkBtn('Download again', true, onAgain));
    t.appendChild(mkBtn('Cancel', false, onCancel));
    t.style.pointerEvents = 'auto';
    t.style.opacity = '1';
    t._mtTimer = setTimeout(dismiss, 20000);
  }

  // Timing markers for diagnosis (also readable by tests via
  // window.__mtTimes: ms since the page loaded).
  function mtMark(name) {
    try {
      window.__mtTimes = window.__mtTimes || {};
      window.__mtTimes[name] = Math.round(performance.now());
      console.log('[MT-TIME] ' + name + ' +' + window.__mtTimes[name] + 'ms');
    } catch (e) {}
  }

  // Best-URL cache, warmed while the video plays: asking the
  // background for the observed URL costs a service-worker round trip
  // (slow when the worker is asleep), so it is resolved ahead of the
  // click and refreshed while the video plays. On click a cache entry
  // younger than 90 s is used straight away — the save then starts in
  // ~0 ms. A failed fetch re-resolves for a fresh URL (see
  // attemptFetch) instead of trusting the cache.
  var bestCache = new Map(); // video -> {found, at, src, playAt}
  function warmBest(video) {
    if (!video || !video.isConnected) return;
    var c = bestCache.get(video);
    if (c && Date.now() - c.at < 60000 && c.playAt === getPlayStartedAt(video)) return; // already warm
    resolveBestUrl(video).then(function (found) {
      if (found && (found.url || found.merge)) {
        bestCache.set(video, { found: found, at: Date.now(), src: video.currentSrc || video.src || '', playAt: getPlayStartedAt(video) });
      }
    }).catch(function () {});
  }
  function pickBestUrl(video) {
    var cached = bestCache.get(video);
    if (cached && (Date.now() - cached.at < 90000) &&
        cached.src === (video.currentSrc || video.src || '') &&
        cached.playAt === getPlayStartedAt(video) &&
        cached.found && (cached.found.url || cached.found.merge)) {
      return Promise.resolve(cached.found);
    }
    return resolveBestUrl(video);
  }

  // True when the URL is covered by the extension's net-request
  // rules (rules.json + the per-click dynamic rule): a main-frame
  // navigation to it gets `Content-Disposition: attachment`, so an
  // anchor click starts a download instead of navigating. Anything
  // else must NOT take the anchor path — without the rule the click
  // would just open the video.
  function isDnrCovered(u) {
    if (!isHttpUrl(u)) return false;
    if (u.indexOf('mime_type=video_mp4') !== -1) return true;
    if (VIDEO_CDN_RE.test(u)) return true;
    return false;
  }

  /* ---------- best URL resolution (async — asks the background) ---------- */

  // Ask the background worker what media was fetched while THIS video
  // was playing (its webRequest observer saw the real sizes, with the
  // time each fetch started). `since` is the epoch ms the video
  // element started playing. Resolves to {bestMp4, bestSize, stream}
  // or null when nothing can be tied to this video — the tab-global
  // best (v1.6) is gone because it picked the wrong video on feeds.
  function askBackgroundBestForVideo(video) {
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage({ type: 'MT_BEST_FOR_VIDEO', since: getPlayStartedAt(video) }, function (res) {
          if (chrome.runtime.lastError || !res || !res.ok) resolve(null);
          else resolve(res);
        });
      } catch (e) {
        resolve(null);
      }
    });
  }

  // YouTube video id for this page (watch / Shorts / embed).
  function youtubeVideoId() {
    var m = location.search.match(/[?&]v=([A-Za-z0-9_-]{6,})/);
    if (m) return m[1];
    var p = location.pathname.match(/\/(?:shorts|embed|live)\/([A-Za-z0-9_-]{6,})/);
    return p ? p[1] : null;
  }

  // YouTube player API (ANDROID client) called from THIS page (same
  // origin, so the page's cookies/origin are sent — the background
  // worker's identical POST is answered 403, proven 2026-11-23).
  // The ANDROID client returns all formats WITH direct googlevideo
  // URLs (the browser WEB player response has none — SABR/UMP only).
  // The key is the public web client key embedded in every YouTube
  // page, not a secret. Returns {progressive, videoOnly, audioOnly}
  // (same shape as the background's MT_YT_ADAPTIVE), or null.
  function parseYtStreamingData(sd) {
    var out = { progressive: [], videoOnly: [], audioOnly: null };
    if (!sd) return out;
    var list = sd.formats || [];
    for (var i = 0; i < list.length; i++) {
      var f = list[i];
      if (!f || !f.url || typeof f.mimeType !== 'string') continue;
      if (f.mimeType.indexOf('video/mp4') !== 0) continue;
      out.progressive.push({ itag: f.itag || 0, mime: f.mimeType.split(';')[0], url: f.url, w: f.width || 0, h: f.height || 0, q: f.qualityLabel || '' });
    }
    out.progressive.sort(function (a, b) { return (b.h || 0) - (a.h || 0); });
    var adapt = sd.adaptiveFormats || [];
    for (var j = 0; j < adapt.length; j++) {
      var g = adapt[j];
      if (!g || !g.url || typeof g.mimeType !== 'string') continue;
      var mime = g.mimeType.split(';')[0];
      if (mime === 'video/mp4' && !g.audioQuality) {
        out.videoOnly.push({ itag: g.itag || 0, mime: mime, url: g.url, w: g.width || 0, h: g.height || 0, q: g.qualityLabel || '' });
      } else if (mime === 'audio/mp4') {
        var br = g.bitrate || 0;
        if (!out.audioOnly || br > (out.audioOnly.bitrate || 0)) {
          out.audioOnly = { itag: g.itag || 0, mime: mime, url: g.url, bitrate: br };
        }
      }
    }
    out.videoOnly.sort(function (a, b) { return (b.h || 0) - (a.h || 0); });
    return out;
  }
  function fetchYtPlayerApi(vid) {
    return fetch('https://www.youtube.com/youtubei/v1/player?key=AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8&prettyPrint=false', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ context: { client: { clientName: 'ANDROID', clientVersion: '20.10.38', androidSdkVersion: 30 } }, videoId: vid })
    }).then(function (r) {
      if (!r.ok) return null;
      return r.json().then(function (j) {
        if (!j || !j.streamingData) return null;
        return parseYtStreamingData(j.streamingData);
      });
    }).catch(function () { return null; });
  }

  // YouTube: the player serves SABR/UMP streams only — no
  // progressive mp4 in the player response, no direct adaptive URLs,
  // and the observed videoplayback URL is not a file. Save a
  // progressive mp4 when the player response lists one; otherwise
  // merge the best video-only mp4 + best audio m4a in the offscreen
  // document (ffmpeg.wasm, -c copy, no re-encode). If neither exists,
  // report the stream honestly (never a fake or silent file).
  // Quality rule: prefer the MERGE when the best video-only mp4 is
  // taller than the best progressive (e.g. this video's progressive
  // is only 360p itag 18, while the merge gives 720p) — the merged
  // file keeps the best available quality. The guard key is
  // 'yt:<videoId>' — the googlevideo path is the same
  // (/videoplayback) for every video, so it cannot identify one.
  function pickYoutubeSave(res, key) {
    if (!res || !res.ok) return null;
    var prog = (res.progressive && res.progressive.length > 0) ? res.progressive[0] : null;
    var vid = (res.videoOnly && res.videoOnly.length > 0) ? res.videoOnly[0] : null;
    var aud = (res.audioOnly && res.audioOnly.url) ? res.audioOnly : null;
    // Merge candidates capped at 720p (the standing quality rule):
    // the list's tallest is 2160p/298 MB, far too big — 720p is the
    // target, falling back to the smallest available when nothing is
    // at or under 720p.
    var cands = null;
    if (res.videoOnly && res.videoOnly.length > 0) {
      cands = res.videoOnly.filter(function (c) { return (c.h || 0) <= 720; });
      if (!cands.length) cands = [res.videoOnly[res.videoOnly.length - 1]];
    }
    if (vid && aud && (!prog || (vid.h || 0) > (prog.h || 0))) {
      return { merge: true, via: 'youtube', fresh: true, ext: 'mp4', key: key,
        videoCandidates: cands, audioUrl: aud.url, audioItag: aud.itag || 0 };
    }
    if (prog) return { url: prog.url, via: 'youtube', fresh: true, ext: 'mp4', key: key };
    if (vid && aud) {
      return { merge: true, via: 'youtube', fresh: true, ext: 'mp4', key: key,
        videoCandidates: cands, audioUrl: aud.url, audioItag: aud.itag || 0 };
    }
    return null;
  }
  function resolveYouTube() {
    var vid = youtubeVideoId();
    var key = vid ? ('yt:' + vid) : '';
    return sendBg({ type: 'MT_YT_ADAPTIVE', videoId: vid || '' }).then(function (res) {
      var picked = pickYoutubeSave(res, key);
      if (picked) return picked;
      // The page's player response has no usable URLs (SABR/UMP) —
      // ask the player API with the ANDROID client from this page.
      if (!vid) return { error: 'stream' };
      return fetchYtPlayerApi(vid).then(function (api) {
        var p2 = api ? pickYoutubeSave({ ok: true, progressive: api.progressive, videoOnly: api.videoOnly, audioOnly: api.audioOnly }, key) : null;
        return p2 || { error: 'stream' };
      });
    }).catch(function () { return { error: 'stream' }; });
  }

  // Vimeo: the player lists progressive mp4s in its player config
  // (request.files.progressive), which the player itself never
  // fetches as media — so read the config directly, in the page
  // context (MAIN world first, isolated fetch as fallback).
  function vimeoVideoId() {
    var m = location.pathname.match(/(\d+)(?:\/)?$/);
    return m ? m[1] : null;
  }

  // Standalone + unit-testable: best progressive mp4 URL from a
  // Vimeo player-config JSON string, or null.
  function parseVimeoProgressive(configText) {
    try {
      var cfg = JSON.parse(configText);
      var files = (cfg.request && cfg.request.files) || {};
      var list = files.progressive || [];
      var best = null;
      for (var i = 0; i < list.length; i++) {
        var f = list[i];
        if (!f || !f.url) continue;
        if (f.mime && f.mime.indexOf('video/') !== 0) continue;
        var score = (f.height || 0) * 1000 + (f.width || 0);
        if (!best || score > best.score) best = { url: f.url, score: score };
      }
      return best ? best.url : null;
    } catch (e) { return null; }
  }

  function resolveVimeo() {
    var id = vimeoVideoId();
    if (!id) return Promise.resolve(null);
    var url = 'https://player.vimeo.com/video/' + id + '/config';
    function fromText(t) {
      var u = parseVimeoProgressive(t || '');
      return u ? { url: u, via: 'vimeo', fresh: true, ext: 'mp4' } : null;
    }
    return sendBg({ type: 'MT_FETCH_TEXT', url: url }).then(function (res) {
      if (res && res.ok && res.text) return fromText(res.text);
      // MAIN-world fetch failed — try the isolated world directly.
      return fetch(url).then(function (r) {
        if (!r.ok) return null;
        return r.text().then(fromText);
      }).catch(function () { return null; });
    }).catch(function () { return null; });
  }

  // Facebook: the reel id for THIS video element — from the page
  // URL on a single-reel page, else from the nearest reel link
  // around the video (feed pages show many reels at once).
  function facebookReelId(video) {
    var m = location.pathname.match(/\/reel\/(\d+)/);
    if (m) return m[1];
    var el = video;
    for (var i = 0; i < 10 && el; i++) {
      if (el.tagName === 'A' && el.href) {
        var hm = el.href.match(/\/reel\/(\d+)/);
        if (hm) return hm[1];
      }
      if (el.querySelectorAll) {
        var links = el.querySelectorAll('a[href*="/reel/"]');
        for (var j = 0; j < links.length; j++) {
          var lm = (links[j].href || '').match(/\/reel\/(\d+)/);
          if (lm) return lm[1];
        }
      }
      el = el.parentElement;
    }
    return null;
  }

  function unescapeJsonUrl(u) {
    return String(u || '').replace(/\\\//g, '/').replace(/\\u0026/g, '&').replace(/&amp;/g, '&');
  }

  // Extract the videoDeliveryLegacyFields objects from a Facebook
  // page's HTML by brace-matching (the objects are flat JSON with
  // string values, so a string-aware scan finds their exact end).
  function extractLegacyFields(html) {
    var out = [];
    var key = '"videoDeliveryLegacyFields":{';
    var i = 0;
    while (true) {
      var start = html.indexOf(key, i);
      if (start === -1) break;
      var pos = start + key.length - 1; // at the '{'
      var depth = 0, inStr = false, esc = false, end = -1;
      for (var p = pos; p < html.length; p++) {
        var ch = html[p];
        if (inStr) {
          if (esc) esc = false;
          else if (ch === '\\') esc = true;
          else if (ch === '"') inStr = false;
        } else {
          if (ch === '"') inStr = true;
          else if (ch === '{') depth++;
          else if (ch === '}') { depth--; if (depth === 0) { end = p; break; } }
        }
      }
      if (end === -1) break;
      out.push(html.slice(pos, end + 1));
      i = end + 1;
    }
    return out;
  }

  // Standalone + unit-testable: the best progressive URL for one reel
  // id from a Facebook page's HTML, or null. Matches the
  // videoDeliveryLegacyFields entry whose dash_manifest_url carries
  // v=<reelId>; when the id is unknown, only a single entry is
  // trusted (on a feed with many reels, guessing would save the
  // wrong video). Prefers the HD URL, falls back to SD.
  function parseFacebookReelUrl(html, reelId) {
    try {
      var text = String(html || '');
      var fields = extractLegacyFields(text);
      var entries = [];
      for (var i = 0; i < fields.length; i++) {
        var obj = null;
        try { obj = JSON.parse(fields[i]); } catch (e) { obj = null; }
        if (obj && (obj.browser_native_hd_url || obj.browser_native_sd_url)) {
          var vid = null;
          if (obj.dash_manifest_url) {
            var vm = String(obj.dash_manifest_url).match(/[?&]v=(\d+)/);
            if (vm) vid = vm[1];
          }
          entries.push({ hd: obj.browser_native_hd_url || null, sd: obj.browser_native_sd_url || null, vid: vid });
        }
      }
      // Fallback: regex scan (in case the brace matcher missed an
      // entry because of an unusual nested value).
      if (!entries.length) {
        var hdRe = /"browser_native_hd_url":"([^"]+)"/g;
        var sdRe = /"browser_native_sd_url":"([^"]+)"/g;
        var dashRe = /"dash_manifest_url":"([^"]+)"/g;
        var raw = [];
        var mm;
        while ((mm = hdRe.exec(text)) !== null) raw.push({ kind: 'hd', url: mm[1], at: mm.index });
        while ((mm = sdRe.exec(text)) !== null) raw.push({ kind: 'sd', url: mm[1], at: mm.index });
        var dashes = [];
        while ((mm = dashRe.exec(text)) !== null) dashes.push({ url: mm[1], at: mm.index });
        for (var k = 0; k < raw.length; k++) {
          var best = null;
          for (var d = 0; d < dashes.length; d++) {
            if (dashes[d].at < raw[k].at && (!best || dashes[d].at > best.at)) best = dashes[d];
          }
          var id2 = null;
          if (best) {
            var vm2 = unescapeJsonUrl(best.url).match(/[?&]v=(\d+)/);
            if (vm2) id2 = vm2[1];
          }
          entries.push({ hd: raw[k].kind === 'hd' ? raw[k].url : null, sd: raw[k].kind === 'sd' ? raw[k].url : null, vid: id2 });
        }
      }
      var hd = null, sd = null;
      for (var j = 0; j < entries.length; j++) {
        if (reelId) {
          if (entries[j].vid !== reelId) continue;
        } else if (entries.length !== 1) {
          continue; // cannot tell which reel this URL belongs to
        }
        if (entries[j].hd && !hd) hd = entries[j].hd;
        if (entries[j].sd && !sd) sd = entries[j].sd;
      }
      var pick = hd || sd;
      return pick ? unescapeJsonUrl(pick) : null;
    } catch (e) { return null; }
  }

  // Facebook: the reel plays via MSE with zero media requests, but
  // the page embeds a progressive URL for THAT reel id in
  // videoDeliveryLegacyFields. Read it from the LIVE DOM
  // (documentElement.outerHTML) — re-fetching location.href returns
  // a lighter logged-out variant WITHOUT the delivery fields
  // (proven 2026-11-23: fetch() HTML 495 KB, 0 entries; live DOM
  // 1.8 MB, 6 hd + 6 sd + 6 dash entries). Returns null when the id
  // cannot be found or the page has no entry for it — the caller
  // then falls back to the per-video timing resolution.
  function resolveFacebook(video) {
    var reelId = facebookReelId(video);
    try {
      var html = document.documentElement ? document.documentElement.outerHTML : '';
      var u = parseFacebookReelUrl(html, reelId);
      return Promise.resolve(u ? { url: u, via: 'facebook', fresh: true, ext: 'mp4' } : null);
    } catch (e) { return Promise.resolve(null); }
  }

  function resolveBestUrl(video) {
    // Platform branches first: their players do not expose a plain
    // <video src>, so the generic steps below would find nothing
    // but a blob URL.
    if (/youtube\.com$/i.test(location.hostname)) {
      return resolveYouTube();
    }
    if (/(^|\.)facebook\.com$/i.test(location.hostname)) {
      return resolveFacebook(video).then(function (found) {
        if (found) return found;
        return resolveBestUrlGeneric(video);
      });
    }
    if (/(^|\.)vimeo\.com$/i.test(location.hostname)) {
      return resolveVimeo().then(function (found) {
        if (found) return found;
        return resolveBestUrlGeneric(video);
      });
    }
    return resolveBestUrlGeneric(video);
  }

  function resolveBestUrlGeneric(video) {
    // (a) What the browser is playing right now — usually the best
    // rendition the site served for this screen.
    var current = video.currentSrc || video.src || '';
    if (isSaveableVideoUrl(current)) return Promise.resolve({ url: current, via: 'direct', fresh: true });

    // (b) <source> children — pick the largest resolution hint.
    var best = null;
    var bestScore = -1;
    var sources = video.querySelectorAll ? video.querySelectorAll('source') : [];
    for (var i = 0; i < sources.length; i++) {
      var s = sources[i].src || sources[i].getAttribute('src') || '';
      if (!isSaveableVideoUrl(s)) continue;
      var sc = resolutionScore(s, sources[i]);
      if (sc >= bestScore) { bestScore = sc; best = s; }
    }
    if (best) return Promise.resolve({ url: best, via: 'direct', fresh: true });

    var sawStream = isStreamUrl(current);

    // (c) Blob/MSE playback: ask the background worker for the media
    // fetched while THIS video was playing (timed to the element's
    // play start). A URL from another video's fetch window is never
    // returned by the strict tier — that is the v1.6 wrong-video bug,
    // fixed here. When nothing can be tied to this video by the
    // strict window, the background falls back to the most recently
    // active fetch that started at/before this video's play start,
    // then to the freshest observed mp4 in the tab (v1.7 fix,
    // 2026-11-23: TikTok preloads finish before the play event and
    // long watches outlive the freshness window, so the strict
    // window alone reported "link not found" on many real videos).
    // There is deliberately NO performance-timeline fallback — it is
    // tab-global too, and it is how the wrong file got picked.
    return askBackgroundBestForVideo(video).then(function (bg) {
      if (bg && bg.bestMp4 && isSaveableVideoUrl(bg.bestMp4)) {
        return { url: bg.bestMp4, via: 'background', fresh: !!bg.fresh, seenAt: bg.seenAt || 0, ext: mimeToExt(bg.mime) };
      }
      if (bg && bg.stream) sawStream = true;

      // (d) Only a stream/DRM format was found — never fake a file,
      // and never save a 2-second logo clip as if it were the video.
      if (sawStream) return { error: 'stream' };
      return { error: 'notfound' };
    });
  }

  // Download-folder setting (popup, chrome.storage.local mt_folder):
  // cached here so the click costs no storage round trip; kept fresh
  // by onChanged. The background applies the same folder on its own
  // paths — applyFolder is idempotent, so a filename that already
  // carries the folder is never prefixed twice.
  var mtFolder = '';
  function mtSanitizeFolder(raw) {
    if (typeof raw !== 'string') return '';
    var t = raw.trim();
    if (!t || t.length > 100) return '';
    if (t.charAt(0) === '/' || t.charAt(0) === '\\' || t.indexOf(':') !== -1 || t.indexOf('\\') !== -1) return '';
    var parts = t.split('/');
    if (parts.length > 5) return '';
    for (var i = 0; i < parts.length; i++) {
      var s = parts[i].trim();
      if (!s || s === '.' || s === '..') return '';
      if (/[<>:"|?*\x00-\x1F]/.test(s)) return '';
      if (s.charAt(s.length - 1) === '.' || s.charAt(s.length - 1) === ' ') return '';
    }
    return parts.map(function (p) { return p.trim(); }).join('/');
  }
  function mtApplyFolder(filename) {
    var name = String(filename || 'video.mp4');
    if (!mtFolder) return name;
    var prefix = mtFolder + '/';
    if (name.indexOf(prefix) === 0) return name;
    return prefix + name;
  }
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get({ mt_folder: '' }, function (r) {
        mtFolder = mtSanitizeFolder(r && r.mt_folder);
      });
      if (chrome.storage.onChanged) {
        chrome.storage.onChanged.addListener(function (changes, area) {
          if (area === 'local' && changes.mt_folder) mtFolder = mtSanitizeFolder(changes.mt_folder.newValue);
        });
      }
    }
  } catch (e) { /* folder stays Auto */ }

  // DASH byte-range params (Instagram): strip bytestart/byteend so
  // a ranged fragment URL becomes the whole-file URL (the bare URL
  // serves ftyp+moov+all fragments; a single range is unplayable).
  function stripByteRange(u) {
    if (typeof u !== 'string') return u;
    if (u.indexOf('bytestart=') === -1 && u.indexOf('byteend=') === -1) return u;
    var q = u.indexOf('?');
    if (q === -1) return u;
    var kept = u.slice(q + 1).split('&').filter(function (p) { return p.indexOf('bytestart=') !== 0 && p.indexOf('byteend=') !== 0; });
    return kept.length ? u.slice(0, q + 1) + kept.join('&') : u.slice(0, q);
  }

  // A signed video-CDN URL (signature/token params in the query, or
  // a video CDN host) is only accepted by the CDN when the request
  // comes from the page itself — a direct browser download of it
  // fails. Those URLs must go through the in-page anchor/fetch path,
  // never the direct path.
  function isSignedUrl(u) {
    if (!isHttpUrl(u)) return false;
    if (VIDEO_CDN_RE.test(u)) return true;
    return /[?&](ft|rc|x-expires|x-signature|signature|token|expire|tk|auth|key|sig|oh|oe)=/i.test(u);
  }

  // Promise wrapper for extension messages.
  function sendBg(msg) {
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage(msg, function (res) {
          if (chrome.runtime.lastError) {
            console.warn('[MT] sendBg lastError (' + msg.type + '):', chrome.runtime.lastError.message);
            resolve(null);
          } else resolve(res || null);
        });
      } catch (e) {
        resolve(null);
      }
    });
  }

  // Fetch a URL with progress reports. NO credentials are sent: the
  // video CDNs answer `Access-Control-Allow-Origin: *` WITHOUT
  // `Access-Control-Allow-Credentials`, so a credentialed fetch fails
  // CORS ("Failed to fetch") while an uncredentialed one returns 200
  // (proven live). The signed URL itself carries all the
  // authorisation the CDN needs.
  function fetchWithProgress(url, onProgress) {
    return fetch(url).then(function (res) {
      if (!res.ok) return { ok: false, status: res.status };
      var total = parseInt(res.headers.get('content-length') || '', 10);
      if (isNaN(total)) total = 0;
      if (!res.body || typeof res.body.getReader !== 'function') {
        return res.arrayBuffer().then(function (buf) {
          if (onProgress) onProgress(buf.byteLength, total);
          return { ok: true, buf: buf };
        });
      }
      var reader = res.body.getReader();
      var chunks = [];
      var received = 0;
      function pump() {
        return reader.read().then(function (r) {
          if (r.done) {
            var all = new Uint8Array(received);
            var off = 0;
            for (var i = 0; i < chunks.length; i++) { all.set(chunks[i], off); off += chunks[i].length; }
            return { ok: true, buf: all.buffer };
          }
          chunks.push(r.value);
          received += r.value.byteLength;
          if (onProgress) onProgress(received, total);
          return pump();
        });
      }
      return pump();
    });
  }

  // Save a Blob with a plain in-page anchor click (page-initiated
  // download — no extension download call involved). When an
  // existing blob URL is passed, that URL is used (so the background
  // can match the download to its MT_WATCH entry) and NOT revoked
  // here — the caller revokes it.
  function anchorDownload(blob, filename, existingUrl) {
    var url = existingUrl || URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.style.display = 'none';
    document.documentElement.appendChild(a);
    a.click();
    a.remove();
    if (!existingUrl) setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
  }

  // Save an already-fetched Blob: register the watch with the
  // background first (so its completion toast is not missed), then
  // click the anchor. Returns {ok:'anchor'} once the save started.
  function saveBlob(blob, filename, key) {
    var blobUrl = URL.createObjectURL(blob);
    // The download manager reads the blob URL on its own schedule,
    // so keep it alive a while before revoking it.
    setTimeout(function () { try { URL.revokeObjectURL(blobUrl); } catch (e) {} }, 120000);
    return sendBg({ type: 'MT_WATCH', url: blobUrl, filename: filename, key: key || '' }).then(function () {
      mtMark('anchor-click');
      anchorDownload(blob, filename, blobUrl);
      return { ok: 'anchor' };
    });
  }

  // Fetch the video IN THE PAGE (page origin — the only context signed
  // video URLs accept) and save it with an in-page anchor click. Why
  // an anchor, not the background's download manager? The background
  // cannot create blob URLs (URL.createObjectURL does not exist in a
  // service worker), and when it downloads a blob URL the file lands
  // under the blob's UUID — Chrome drops the filename option for blob
  // downloads and onDeterminingFilename never fires for them (proven
  // in headless runs, 2026-11-21). The anchor's download attribute IS
  // honoured, so the file gets its real name. Before clicking, the
  // background is told to watch for the download (MT_WATCH) so it can
  // still toast "Saved." only when it really completes.
  // Returns {ok:'anchor'} when the save started.
  function fetchAndTransfer(url, filename) {
    mtMark('fetch-start');
    var key = keyForUrl(url);
    return fetchWithProgress(url, function (received, total) {
      if (total > 0) toast('Saving… ' + Math.round(received / total * 100) + '%', 30000);
    }).then(function (r) {
      if (!r || !r.ok) {
        // The isolated-world fetch failed — try the page's MAIN world
        // (same origin, different JS world) before giving up.
        if (!r || !r.status) return fetchMainWorld(url, filename, key);
        return r;
      }
      if (!r.buf || r.buf.byteLength === 0) return { ok: false, error: 'empty' };
      mtMark('fetch-done');
      return saveBlob(new Blob([r.buf], { type: 'video/mp4' }), filename, key);
    }).catch(function (e) {
      console.warn('[MT] transfer broke:', e && e.message);
      return fetchMainWorld(url, filename, key).catch(function () {
        return { ok: false, error: String((e && e.message) || e) };
      });
    });
  }

  // Fetch in the page's MAIN world through the background worker
  // (chrome.scripting, world:'MAIN'). The MAIN world returns only a
  // blob URL string (ArrayBuffers cannot cross the extension-message
  // boundary), so the anchor click also runs there. Returns the same
  // {ok:'anchor'} shape as the isolated path.
  function fetchMainWorld(url, filename, key) {
    mtMark('main-fetch-start');
    return sendBg({ type: 'MT_FETCH_MAIN', url: url }).then(function (res) {
      if (!res || !res.ok || !res.blobUrl) {
        return { ok: false, status: res && res.status, error: res && res.error };
      }
      mtMark('main-fetch-done');
      return sendBg({ type: 'MT_WATCH', url: res.blobUrl, filename: filename, key: key || '' }).then(function () {
        return sendBg({ type: 'MT_ANCHOR_MAIN', blobUrl: res.blobUrl, filename: filename }).then(function (r2) {
          if (r2 && r2.ok) { mtMark('anchor-click'); return { ok: 'anchor' }; }
          return { ok: false, error: (r2 && r2.error) || 'anchor failed' };
        });
      });
    });
  }

  // Instant download: a plain anchor click on the video URL. On its
  // own Chrome ignores the download attribute for cross-origin URLs
  // (proven: _blank does nothing, no-target navigates the tab away),
  // BUT the extension's declarativeNetRequest rules add
  // `Content-Disposition: attachment` to main-frame navigations to
  // the video CDNs (rules.json), so the click starts a real download
  // immediately — no waiting for a fetch (proven live: file in
  // Downloads ~1 s after the click, page untouched). target=_blank
  // keeps the page safe: if the rule ever misses, the video opens in
  // a new tab instead of replacing this one, and the background
  // closes it and falls back to the fetch path.
  function anchorDirectDownload(url, filename) {
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.target = '_blank';
    // NOTE: no rel="noopener" on purpose — the background tracks the
    // blank tab through its openerTabId so it can close it once the
    // download starts. The link points at a video file, not a page,
    // so opener access is not a risk here.
    a.style.display = 'none';
    document.documentElement.appendChild(a);
    a.click();
    a.remove();
  }

  // Ask the background to register the filename + watch for the
  // download, then click the anchor. Returns the background's
  // response: {ok:true} when clicked, {ok:false, dup:'downloading'|
  // 'saved'} when this video was already saved. force=true bypasses
  // the duplicate guard for one explicit re-download.
  function anchorSave(url, filename, key, force) {
    return sendBg({ type: 'MT_ANCHOR', url: url, filename: filename, key: key || '', force: !!force }).then(function (res) {
      if (res && res.ok) {
        mtMark('anchor-click');
        anchorDirectDownload(url, filename);
        return res;
      }
      return res || { ok: false };
    });
  }

  // One fetch attempt (isolated world, then MAIN world), with a single
  // fresh-URL retry when the first URL no longer works.
  function attemptFetch(video, found, filename, retried) {
    fetchAndTransfer(found.url, filename).then(function (r) {
      if (r && r.ok === true) {
        // Background watches the download and toasts "Saved." only
        // when it really completes.
        return;
      }
      if (r && r.ok === 'anchor') {
        toast('Saving started — check your Downloads folder.');
        return;
      }
      if (!retried) {
        resolveBestUrl(video).then(function (fresh) {
          if (fresh && fresh.url && fresh.url !== found.url) {
            attemptFetch(video, fresh, filename, true);
          } else {
            reportFetchFailure(r, found);
          }
        });
        return;
      }
      reportFetchFailure(r, found);
    });
  }

  function reportFetchFailure(r, found) {
    // The attempt finally failed: release the duplicate guard so the
    // user can retry this video.
    try { sendBg({ type: 'MT_RELEASE', key: keyForUrl(found.url) }); } catch (e) {}
    if (found.fresh === false) {
      toast('Play the video again, then try.');
    } else if (r && r.status) {
      toast('Save failed: server ' + r.status + ' — please try again.');
    } else {
      console.warn('[MT] save failed:', JSON.stringify(r), 'fresh:', found.fresh);
      toast('Save failed — please try again.');
    }
  }

  /* ---------- button (fixed position, page DOM untouched) ---------- */

  function makeButton(video) {
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = BTN_CLASS;
    btn.title = 'Save video';
    btn.setAttribute('aria-label', 'Save video');
    btn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" ' +
      'xmlns="http://www.w3.org/2000/svg"><path d="M12 3v12m0 0l-4.5-4.5M12 15l4.5-4.5M4 19h16" ' +
      'stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    btn.style.cssText = 'position:fixed;width:34px;height:34px;' +
      'border:none;border-radius:50%;background:rgba(0,0,0,0.55);cursor:pointer;' +
      'display:none;align-items:center;justify-content:center;padding:0;' +
      'z-index:2147483647;opacity:0.85;transition:opacity 0.15s, background 0.15s;';
    btn.addEventListener('mouseenter', function () { btn.style.opacity = '1'; btn.style.background = 'rgba(13,148,136,0.9)'; });
    btn.addEventListener('mouseleave', function () { btn.style.opacity = '0.85'; btn.style.background = 'rgba(0,0,0,0.55)'; });
    btn.addEventListener('click', function (ev) {
      ev.stopPropagation();
      ev.preventDefault();
      onSaveClick(video);
    });
    return btn;
  }

  // The video is already saved on this PC: ask before downloading
  // it again. "Download again" starts a fresh download (guard
  // bypassed for that one click); "Cancel" — or ignoring the
  // prompt — downloads nothing.
  function showAlreadySavedPrompt(video, found, filename, key) {
    confirmToast('This file is already downloaded. Download again?', function () {
      toast('Saving…', 30000);
      savingVideos.add(video);
      startSave(video, found, filename, key, true);
    }, function () {
      // Cancel: nothing downloads.
    });
  }

  // Handle a duplicate answer from the background. Returns true when
  // the answer was a duplicate (the caller must not fall through to
  // the fetch path).
  function handleDup(video, found, filename, key, res) {
    if (!res || !res.dup) return false;
    if (res.dup === 'saved') {
      showAlreadySavedPrompt(video, found, filename, key);
    } else {
      // Still downloading: no second download, just the toast.
      toast('Already downloading.');
    }
    return true;
  }

  // Start the save for a resolved video URL. force=true bypasses the
  // duplicate guard (only used after the user chose "Download again").
  function startSave(video, found, filename, key, force) {
    // Merge request (YouTube adaptive / HLS-DASH): the offscreen
    // document fetches the streams, muxes them with ffmpeg.wasm
    // (-c copy, no re-encode) and saves the merged file. The
    // background reserves the duplicate guard and toasts "Saved."
    // when the download completes.
    if (found.merge) {
      sendBg({ type: 'MT_MERGE', videoCandidates: found.videoCandidates || [], audioUrl: found.audioUrl || null, audioItag: found.audioItag || 0, manifestUrl: found.manifestUrl || null, filename: filename, key: key, force: !!force }).then(function (res) {
        savingVideos.delete(video);
        if (handleDup(video, found, filename, key, res)) return;
        if (!res || !res.ok) {
          toast('Save failed: ' + ((res && res.error) || 'please try again.'));
        }
      });
      return;
    }
    // DASH byte-range URLs (Instagram): a single range is an
    // unplayable fragment — the bare URL is the whole file, so save
    // that (the background observer already strips the range params
    // too; this covers direct/currentSrc URLs as well).
    if (found.url) found.url = stripByteRange(found.url);
    // Signed video-CDN URLs: the instant anchor path (the
    // extension's net-request rules turn the navigation into a
    // download). The background watches: if no download appears,
    // it asks this page to fall back to the fetch path.
    if (found.via === 'background' || isSignedUrl(found.url) || isDnrCovered(found.url)) {
      anchorSave(found.url, filename, key, force).then(function (res) {
        savingVideos.delete(video);
        if (handleDup(video, found, filename, key, res)) return;
        if (!res || !res.ok) attemptFetch(video, found, filename, false);
      });
      return;
    }
    // Ordinary public video: the browser's own download manager.
    // No toast on start here either — "Saving…" is already showing,
    // and the background toasts "Saved." only when the download
    // really completes (or the real reason when it fails, retrying
    // through the page fetch first).
    chrome.runtime.sendMessage(
      { type: 'MT_SAVE', url: found.url, filename: filename, key: key, force: !!force },
      function (res) {
        savingVideos.delete(video);
        if (chrome.runtime.lastError) {
          toast('Save failed: ' + chrome.runtime.lastError.message);
        } else if (handleDup(video, found, filename, key, res)) {
          return;
        } else if (res && !res.ok) {
          toast('Save failed: ' + (res.error || 'unknown error'));
        }
      }
    );
  }

  function onSaveClick(video) {
    // Rapid double-click on the same video: answer at once, without
    // starting a second save. (The background's persisted record is
    // the real guard — this only covers the milliseconds before the
    // first click reaches it.)
    if (savingVideos.has(video)) {
      toast('Already downloading.');
      return;
    }
    savingVideos.add(video);
    mtMark('click');
    // Instant feedback: the save is working from this moment. The
    // file itself appears in Downloads as soon as the browser starts
    // the download (instant on the anchor path, after the fetch on
    // the fallback path) — but the user is never left wondering.
    toast('Saving…', 30000);
    pickBestUrl(video).then(function (found) {
      if (found.error === 'stream') {
        toast('No direct link for this video (stream/DRM format).');
        savingVideos.delete(video);
        return;
      }
      // A merge result carries videoCandidates + audioUrl (or a
      // manifestUrl) instead of a single url — it must reach
      // startSave, which handles merges. (Without this check the
      // merge was rejected here as "couldn't find" — proven
      // 2026-11-23 on the YouTube 720p merge.)
      if (!found.url && !found.merge) {
        toast('Couldn\'t find this video\'s link — please try again.');
        savingVideos.delete(video);
        return;
      }
      var filename = mtApplyFolder(sanitizeFilename(document.title, found.ext));
      // The resolver may supply its own video-identity key (YouTube
      // merges use 'yt:<videoId>'); otherwise the media URL is the key.
      var key = found.key || (found.url ? keyForUrl(found.url) : '');
      startSave(video, found, filename, key, false);
    }).catch(function () {
      savingVideos.delete(video);
      toast('Save failed — please try again.');
    });
  }

  // Messages from the background worker: honest download status, and
  // retry requests when a direct download failed on the site.
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
      if (!msg || typeof msg.type !== 'string') return false;
      if (msg.type === 'MT_TOAST') {
        if (msg.text) toast(msg.text);
        return false;
      }
      if (msg.type === 'MT_FETCH_TRANSFER' && typeof msg.url === 'string') {
        // The background (or the anchor watchdog) asks this page to
        // fetch the video and save it. The background toasts the
        // outcome itself — this handler stays silent to avoid double
        // toasts — but the result decides whether it reports failure.
        fetchAndTransfer(msg.url, msg.filename || 'video.mp4').then(function (r) {
          sendResponse(r || { ok: false, error: 'unknown' });
        });
        return true; // async reply
      }
      return false;
    });
  }

  /* ---------- eligibility & tracking ---------- */

  function isEligible(video) {
    if (!video || video.tagName !== 'VIDEO') return false;
    if (video.readyState < 1) return false; // no metadata yet
    if ((video.videoWidth || 0) < MIN_WIDTH) return false;
    var d = video.duration;
    if (typeof d === 'number' && !isNaN(d)) {
      if (!isFinite(d)) return false; // live stream
      if (d <= 2) return false; // tiny clip / preview
    }
    return true;
  }

  // Position the fixed button at the video's top-right corner in the
  // viewport. getBoundingClientRect already accounts for scrolling,
  // transforms and clipping ancestors — the button can never be
  // hidden by an overflow:hidden parent.
  function refreshButton(video, rec) {
    rec = rec || tracked.get(video);
    if (!rec) return;
    var show = enabled && isEligible(video) && rec.inView;
    if (!show) {
      rec.btn.style.display = 'none';
      return;
    }
    var rect = video.getBoundingClientRect();
    if (!rect || rect.width < MIN_WIDTH || rect.height <= 0) {
      rec.btn.style.display = 'none';
      return;
    }
    // Out of the viewport entirely (scrolled away) — hide.
    if (rect.bottom < 0 || rect.top > window.innerHeight ||
        rect.right < 0 || rect.left > window.innerWidth) {
      rec.btn.style.display = 'none';
      return;
    }
    rec.btn.style.left = Math.max(0, rect.right - 42) + 'px';
    rec.btn.style.top = Math.max(0, rect.top + 8) + 'px';
    rec.btn.style.display = 'flex';
  }

  function refreshAllButtons() {
    tracked.forEach(function (rec, video) { refreshButton(video, rec); });
  }

  function scheduleReposition() {
    if (rafPending) return;
    rafPending = true;
    requestAnimationFrame(function () {
      rafPending = false;
      refreshAllButtons();
    });
  }

  var VIDEO_EVENTS = ['loadedmetadata', 'loadeddata', 'playing', 'play', 'loadstart', 'emptied'];

  function onVideoEvent(ev) {
    var video = ev.target;
    if (video && video.tagName === 'VIDEO') {
      if (ev.type === 'playing' || ev.type === 'play') {
        // (Re)started playing: anchor the URL resolution window here.
        playStartedAt.set(video, Date.now());
        // Warm the best-URL cache while the video plays, so the click
        // needs no worker round trip (see warmBest).
        warmBest(video);
      } else if (ev.type === 'loadstart' || ev.type === 'emptied') {
        // A new video loaded into this element: forget the old window.
        playStartedAt.delete(video);
        bestCache.delete(video);
        // Anchor the new fetch: src was (re)set just now.
        srcSetAt.set(video, Date.now());
      }
      scheduleScan();
      scheduleReposition();
    }
  }

  function ensureButton(video) {
    if (!enabled || !isEligible(video)) {
      var old = tracked.get(video);
      if (old) old.btn.style.display = 'none';
      return;
    }
    var rec = tracked.get(video);
    if (!rec) {
      if (tracked.size >= MAX_VIDEOS) return;
      var btn = makeButton(video);
      document.documentElement.appendChild(btn);
      rec = { btn: btn, inView: false };
      tracked.set(video, rec);
      if (io) io.observe(video);
      VIDEO_EVENTS.forEach(function (name) {
        video.addEventListener(name, onVideoEvent);
      });
    }
    refreshButton(video, rec);
  }

  function removeTracked(video) {
    var rec = tracked.get(video);
    if (!rec) return;
    bestCache.delete(video);
    if (io) { try { io.unobserve(video); } catch (e) {} }
    VIDEO_EVENTS.forEach(function (name) {
      video.removeEventListener(name, onVideoEvent);
    });
    if (rec.btn && rec.btn.parentNode) rec.btn.parentNode.removeChild(rec.btn);
    tracked.delete(video);
  }

  /* ---------- shadow-DOM-aware discovery ---------- */

  // Collect every <video> in a root, descending into shadow roots.
  function collectVideos(root, out) {
    out = out || [];
    if (!root || !root.querySelectorAll) return out;
    var videos = root.querySelectorAll('video');
    for (var i = 0; i < videos.length; i++) out.push(videos[i]);
    var all = root.querySelectorAll('*');
    for (var j = 0; j < all.length; j++) {
      var sr = all[j].shadowRoot;
      if (sr) collectVideos(sr, out);
    }
    return out;
  }

  // Find shadow roots under a node (used for added nodes from mutations).
  function findShadowRoots(node, out) {
    out = out || [];
    if (!node) return out;
    if (node.nodeType === 1) {
      if (node.shadowRoot) out.push(node.shadowRoot);
      var kids = node.children || [];
      for (var i = 0; i < kids.length; i++) findShadowRoots(kids[i], out);
    }
    return out;
  }

  function observeRoot(root) {
    if (!mo || !root || observedRoots.has(root)) return;
    try {
      mo.observe(root, {
        childList: true, subtree: true, attributes: true, attributeFilter: ['src']
      });
      observedRoots.add(root);
    } catch (e) { /* root not observable — ignore */ }
  }

  function scanVideos() {
    if (!enabled || document.hidden) return;
    var videos = collectVideos(document);
    var count = 0;
    for (var i = 0; i < videos.length && count < MAX_VIDEOS; i++) {
      count++;
      ensureButton(videos[i]);
    }
    // Clean up videos that left the document (isConnected works for
    // shadow-DOM videos too, unlike document.contains).
    tracked.forEach(function (rec, video) {
      if (!video.isConnected) removeTracked(video);
    });
    scheduleReposition();
  }

  function scheduleScan() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(scanVideos, DEBOUNCE_MS);
  }

  /* ---------- observers ---------- */

  function onMutations(mutations) {
    // New shadow roots appear with their host elements — watch them too.
    for (var i = 0; i < mutations.length; i++) {
      var added = mutations[i].addedNodes;
      if (!added) continue;
      for (var j = 0; j < added.length; j++) {
        var roots = findShadowRoots(added[j], []);
        for (var k = 0; k < roots.length; k++) observeRoot(roots[k]);
      }
      // A video's src was (re)set — anchor the fetch window NOW, in
      // this microtask, before the player's play() dispatches 'play'/
      // 'playing' (those are tasks). Waiting for the debounced scan
      // loses the race and the anchor stays 0 (the vidB bug).
      if (mutations[i].type === 'attributes' && mutations[i].attributeName === 'src') {
        var t = mutations[i].target;
        if (t && t.tagName === 'VIDEO') {
          srcSetAt.set(t, Date.now());
          ensureButton(t);
        }
      }
    }
    scheduleScan();
  }

  function startObservers() {
    if (mo) return;
    mo = new MutationObserver(onMutations);
    observeRoot(document.documentElement || document.body);
    io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        var rec = tracked.get(entry.target);
        if (rec) {
          rec.inView = entry.isIntersecting && entry.intersectionRatio > 0;
          refreshButton(entry.target, rec);
        }
      });
    }, { threshold: 0.05 });
    tracked.forEach(function (rec, video) { io.observe(video); });
    document.addEventListener('loadedmetadata', onVideoEvent, true);
    // Capture-phase listeners for play state: 'play'/'playing' do not
    // bubble, but a capture listener on document sees them for EVERY
    // video, even one whose per-element listener is not attached yet
    // (blob players set src + play() in one task). Without these the
    // play anchor is missed and the resolution falls back to the
    // tab-global largest file — the wrong video.
    document.addEventListener('play', onVideoEvent, true);
    document.addEventListener('playing', onVideoEvent, true);
    document.addEventListener('loadstart', onVideoEvent, true);
    document.addEventListener('emptied', onVideoEvent, true);
    window.addEventListener('scroll', scheduleReposition, true);
    window.addEventListener('resize', scheduleReposition);
    scanVideos();
  }

  function stopObservers() {
    if (mo) { mo.disconnect(); mo = null; }
    if (io) { io.disconnect(); io = null; }
    observedRoots.clear();
    window.removeEventListener('scroll', scheduleReposition, true);
    window.removeEventListener('resize', scheduleReposition);
    document.removeEventListener('loadedmetadata', onVideoEvent, true);
    document.removeEventListener('play', onVideoEvent, true);
    document.removeEventListener('playing', onVideoEvent, true);
    document.removeEventListener('loadstart', onVideoEvent, true);
    document.removeEventListener('emptied', onVideoEvent, true);
    clearTimeout(debounceTimer);
  }

  /* ---------- lifecycle ---------- */

  function applyEnabled(next) {
    enabled = next !== false;
    if (enabled) {
      startObservers();
    } else {
      stopObservers();
      tracked.forEach(function (rec, video) { removeTracked(video); });
    }
  }

  document.addEventListener('visibilitychange', function () {
    if (document.hidden) {
      stopObservers();
    } else if (enabled) {
      startObservers();
    }
  });

  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get({ enabled: true }, function (res) {
      applyEnabled(res.enabled);
    });
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area === 'local' && changes.enabled) {
        applyEnabled(changes.enabled.newValue);
      }
    });
  } else {
    applyEnabled(true);
  }
})();
