/* Save Video — popup: enable toggle, download folder, ask-each-time.
   All settings persist in chrome.storage.local (enabled, mt_folder,
   mt_ask). The folder is a subfolder inside Downloads; empty means
   Auto — files save directly in Downloads. Invalid folder names are
   ignored (the field reverts to the last valid value). */
document.addEventListener('DOMContentLoaded', () => {
  const box = document.getElementById('enabled');
  const folderInput = document.getElementById('folder');
  const folderCurrent = document.getElementById('folderCurrent');
  const askBox = document.getElementById('ask');
  let lastValidFolder = '';

  function sanitizeFolder(raw) {
    if (typeof raw !== 'string') return '';
    const t = raw.trim();
    if (!t || t.length > 100) return '';
    if (t.startsWith('/') || t.startsWith('\\') || t.includes(':') || t.includes('\\')) return '';
    const parts = t.split('/');
    if (parts.length > 5) return '';
    for (const p of parts) {
      const s = p.trim();
      if (!s || s === '.' || s === '..') return '';
      if (/[<>:"|?*\x00-\x1F]/.test(s)) return '';
      if (s.endsWith('.') || s.endsWith(' ')) return '';
    }
    return parts.map((p) => p.trim()).join('/');
  }

  function showCurrent(folder) {
    if (folder) {
      folderCurrent.textContent = 'Current: ' + folder + ' — files save in Downloads/' + folder + '/';
    } else {
      folderCurrent.textContent = 'Current: Auto — files save directly in Downloads.';
    }
  }

  chrome.storage.local.get({ enabled: true, mt_folder: '', mt_ask: false }, (res) => {
    box.checked = res.enabled !== false;
    lastValidFolder = sanitizeFolder(res.mt_folder);
    folderInput.value = lastValidFolder;
    showCurrent(lastValidFolder);
    askBox.checked = !!res.mt_ask;
  });

  box.addEventListener('change', () => {
    chrome.storage.local.set({ enabled: box.checked });
  });

  folderInput.addEventListener('change', () => {
    const raw = folderInput.value;
    const clean = sanitizeFolder(raw);
    if (raw.trim() !== '' && clean === '') {
      // Invalid name — ignore it and revert to the last valid value.
      folderInput.value = lastValidFolder;
      showCurrent(lastValidFolder);
      return;
    }
    lastValidFolder = clean;
    folderInput.value = clean;
    chrome.storage.local.set({ mt_folder: clean });
    showCurrent(clean);
  });

  askBox.addEventListener('change', () => {
    chrome.storage.local.set({ mt_ask: askBox.checked });
  });
});
